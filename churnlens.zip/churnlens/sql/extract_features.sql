-- =====================================================================
-- ChurnLens | Customer-level modelling table
-- =====================================================================
-- Collapses five relational tables into ONE row per customer.
--   * de-duplicates raw customer rows            (ROW_NUMBER window)
--   * splits usage into recent (last 3 months)
--     vs prior (earlier months) windows          (ROW_NUMBER window + conditional AVG)
--   * counts support friction in the 90 days
--     before the observation end                 (JULIANDAY arithmetic)
--   * summarises billing health                  (conditional SUM)
-- Observation end = churn date for churned customers, snapshot otherwise,
-- so every feature is computed from information available *before* churn.
-- Parameter :snapshot is the "as of" date for active customers.
-- =====================================================================
WITH cust AS (
    SELECT customer_id, signup_date, age, gender, country, company_size, acquisition_channel,
           ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY signup_date) AS rn
    FROM customers
),
base AS (
    SELECT c.customer_id, c.signup_date, c.age, c.gender, c.country, c.company_size,
           c.acquisition_channel,
           s.plan, s.contract_type, s.seats, s.monthly_price, s.add_ons,
           s.payment_method, s.autopay,
           COALESCE(s.end_date, :snapshot)             AS obs_end,
           CASE WHEN s.status = 'churned' THEN 1 ELSE 0 END AS churn
    FROM cust c
    JOIN subscriptions s ON s.customer_id = c.customer_id
    WHERE c.rn = 1
),
usage_ranked AS (
    SELECT u.*,
           ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY period_idx DESC) AS recency_rank
    FROM monthly_usage u
),
usage_agg AS (
    SELECT customer_id,
           COUNT(*)                                                    AS months_observed,
           AVG(CASE WHEN recency_rank <= 3 THEN logins          END)   AS logins_recent,
           AVG(CASE WHEN recency_rank >  3 THEN logins          END)   AS logins_prior,
           AVG(CASE WHEN recency_rank <= 3 THEN active_minutes  END)   AS minutes_recent,
           AVG(CASE WHEN recency_rank >  3 THEN active_minutes  END)   AS minutes_prior,
           AVG(CASE WHEN recency_rank <= 3 THEN features_used   END)   AS features_recent,
           AVG(CASE WHEN recency_rank >  3 THEN features_used   END)   AS features_prior,
           AVG(CASE WHEN recency_rank <= 3 THEN api_calls       END)   AS api_calls_recent,
           AVG(CASE WHEN recency_rank >  3 THEN api_calls       END)   AS api_calls_prior,
           MAX(CASE WHEN recency_rank =  1 THEN logins          END)   AS logins_last_month
    FROM usage_ranked
    GROUP BY customer_id
),
tickets_agg AS (
    SELECT t.customer_id,
           COUNT(*)                                                                  AS tickets_total,
           SUM(CASE WHEN JULIANDAY(b.obs_end) - JULIANDAY(t.created_date) <= 90
                    THEN 1 ELSE 0 END)                                               AS tickets_90d,
           SUM(CASE WHEN t.priority IN ('High', 'Urgent') THEN 1 ELSE 0 END)         AS high_priority_tickets,
           AVG(t.resolution_hours)                                                   AS avg_resolution_hours,
           AVG(t.csat)                                                               AS avg_csat
    FROM support_tickets t
    JOIN base b ON b.customer_id = t.customer_id
    GROUP BY t.customer_id
),
pay_agg AS (
    SELECT customer_id,
           COUNT(*)                                  AS payments_total,
           SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_payments,
           SUM(CASE WHEN status = 'late'   THEN 1 ELSE 0 END) AS late_payments
    FROM payments
    GROUP BY customer_id
)
SELECT b.customer_id,
       b.signup_date,
       b.age, b.gender, b.country, b.company_size, b.acquisition_channel,
       b.plan, b.contract_type, b.seats, b.monthly_price, b.add_ons, b.payment_method, b.autopay,
       CAST(JULIANDAY(b.obs_end) - JULIANDAY(b.signup_date) AS INTEGER) AS tenure_days,
       ua.months_observed,
       ua.logins_recent,  ua.logins_prior,  ua.logins_last_month,
       ua.minutes_recent, ua.minutes_prior,
       ua.features_recent, ua.features_prior,
       ua.api_calls_recent, ua.api_calls_prior,
       COALESCE(ta.tickets_total, 0)          AS tickets_total,
       COALESCE(ta.tickets_90d, 0)            AS tickets_90d,
       COALESCE(ta.high_priority_tickets, 0)  AS high_priority_tickets,
       ta.avg_resolution_hours,
       ta.avg_csat,
       COALESCE(pa.payments_total, 0)         AS payments_total,
       COALESCE(pa.failed_payments, 0)        AS failed_payments,
       COALESCE(pa.late_payments, 0)          AS late_payments,
       b.churn
FROM base b
LEFT JOIN usage_agg   ua ON ua.customer_id = b.customer_id
LEFT JOIN tickets_agg ta ON ta.customer_id = b.customer_id
LEFT JOIN pay_agg     pa ON pa.customer_id = b.customer_id
ORDER BY b.customer_id;
