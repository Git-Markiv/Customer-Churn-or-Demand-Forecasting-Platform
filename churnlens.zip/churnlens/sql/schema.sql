-- ChurnLens demo warehouse schema (SQLite)
-- Five relational tables describing a SaaS subscription business.

DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS subscriptions;
DROP TABLE IF EXISTS monthly_usage;
DROP TABLE IF EXISTS support_tickets;
DROP TABLE IF EXISTS payments;

CREATE TABLE customers (
    customer_id          TEXT,          -- NOT unique on purpose: raw data contains duplicate rows
    signup_date          TEXT,          -- ISO date
    age                  REAL,
    gender               TEXT,
    country              TEXT,
    company_size         TEXT,
    acquisition_channel  TEXT
);

CREATE TABLE subscriptions (
    subscription_id  INTEGER PRIMARY KEY,
    customer_id      TEXT,
    plan             TEXT,
    contract_type    TEXT,
    seats            INTEGER,
    monthly_price    REAL,
    add_ons          INTEGER,
    payment_method   TEXT,
    autopay          INTEGER,           -- 1 = automatic payments enabled
    status           TEXT,              -- 'active' | 'churned'  (the label)
    start_date       TEXT,
    end_date         TEXT               -- churn date, NULL while active
);

CREATE TABLE monthly_usage (
    customer_id     TEXT,
    period_idx      INTEGER,            -- 1..6, 6 = most recent month before observation end
    month_start     TEXT,
    logins          REAL,
    active_minutes  REAL,
    features_used   REAL,
    api_calls       REAL
);

CREATE TABLE support_tickets (
    ticket_id         INTEGER PRIMARY KEY,
    customer_id       TEXT,
    created_date      TEXT,
    category          TEXT,
    priority          TEXT,
    resolution_hours  REAL,
    csat              REAL              -- 1..5, NULL when the customer skipped the survey
);

CREATE TABLE payments (
    payment_id    INTEGER PRIMARY KEY,
    customer_id   TEXT,
    payment_date  TEXT,
    amount        REAL,
    status        TEXT                  -- 'paid' | 'late' | 'failed'
);

CREATE INDEX idx_customers_id ON customers (customer_id);
CREATE INDEX idx_subs_customer ON subscriptions (customer_id);
CREATE INDEX idx_usage_customer ON monthly_usage (customer_id, period_idx);
CREATE INDEX idx_tickets_customer ON support_tickets (customer_id);
CREATE INDEX idx_payments_customer ON payments (customer_id);
