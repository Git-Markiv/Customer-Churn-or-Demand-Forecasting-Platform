@echo off
REM One-click launcher for Windows: creates a venv, installs deps, starts the app.
cd /d %~dp0
if not exist .venv (python -m venv .venv)
call .venv\Scripts\activate
pip install -q -r requirements.txt
streamlit run app.py
