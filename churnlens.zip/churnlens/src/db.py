"""SQL access layer: demo warehouse extraction + SQL over user-supplied data."""
from __future__ import annotations

import re
import sqlite3
from pathlib import Path

import pandas as pd

from .config import DEMO_DB_PATH, SNAPSHOT_DATE, SQL_DIR
from .data_gen import build_demo_database

_FORBIDDEN = re.compile(r"\b(insert|update|delete|drop|alter|create|attach|detach|pragma|replace|vacuum)\b", re.I)


def read_sql_file(name: str) -> str:
    return (SQL_DIR / name).read_text()


def extract_demo_features(db_path: Path | str = DEMO_DB_PATH) -> tuple[pd.DataFrame, str]:
    """Run sql/extract_features.sql against the demo warehouse (built on first use)."""
    db_path = build_demo_database(db_path)
    sql = read_sql_file("extract_features.sql")
    with sqlite3.connect(db_path) as conn:
        df = pd.read_sql_query(sql, conn, params={"snapshot": SNAPSHOT_DATE})
    return df, sql


def validate_select(query: str) -> str:
    """Allow a single read-only SELECT / WITH statement; raise ValueError otherwise."""
    q = query.strip().rstrip(";").strip()
    if not q:
        raise ValueError("The SQL query is empty.")
    if ";" in q:
        raise ValueError("Only a single SQL statement is allowed.")
    if not re.match(r"^(select|with)\b", q, re.I):
        raise ValueError("Only SELECT / WITH queries are allowed.")
    if _FORBIDDEN.search(q):
        raise ValueError("Only read-only queries are allowed (no INSERT/UPDATE/DELETE/DDL).")
    return q


def dataframe_to_memory_db(df: pd.DataFrame, table: str) -> sqlite3.Connection:
    """Load a DataFrame into a throw-away in-memory SQLite database."""
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].dt.strftime("%Y-%m-%d")
    out.to_sql(table, conn, index=False, if_exists="replace")
    return conn


def run_user_sql(df: pd.DataFrame, query: str, table: str = "data") -> pd.DataFrame:
    """Execute a user's read-only SQL against their uploaded table (exposed as `data`)."""
    q = validate_select(query)
    conn = dataframe_to_memory_db(df, table)
    try:
        return pd.read_sql_query(q, conn)
    finally:
        conn.close()


def default_custom_query(columns: list[str], table: str = "data") -> str:
    if len(columns) > 60:
        return f"SELECT *\nFROM {table}"
    cols = ",\n       ".join(f'"{c}"' for c in columns)
    return f"SELECT {cols}\nFROM {table}"
