"""Feature engineering as a scikit-learn transformer (so it runs inside every CV fold).

`FeatureEngineer` creates behavioural features when the relevant raw columns exist
(trend, per-seat intensity, billing health, support burden ...) plus generic
features for any dataset (missing-value flags, month-of-year, "days since" for
`last_*` dates).  Its *schema* (which flags / which top categories) is decided
once from the label-free input data via :meth:`FeatureEngineer.from_data`, so
every fold produces exactly the same columns.
"""
from __future__ import annotations

import re
from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .cleaning import is_text

_RECENT_PRIOR = re.compile(r"^(?P<stem>.+)_recent$")


def _safe_div(num: pd.Series, den: pd.Series) -> pd.Series:
    den = den.replace(0, np.nan)
    return (num / den).replace([np.inf, -np.inf], np.nan)


def _find(cols: Sequence[str], *needles: str, all_of: bool = True) -> str | None:
    """First column whose lower-case name contains the needles."""
    for c in cols:
        low = c.lower()
        ok = all(n in low for n in needles) if all_of else any(n in low for n in needles)
        if ok:
            return c
    return None


def _clean_label(v: object) -> str:
    return re.sub(r"[^0-9A-Za-z_ .\-]+", "", str(v).replace("+", "plus")).strip() or "blank"


class FeatureEngineer(BaseEstimator, TransformerMixin):
    def __init__(self, missing_flag_cols: Sequence[str] = (), top_categories: dict | None = None,
                 id_cols: Sequence[str] = ()):
        self.missing_flag_cols = missing_flag_cols
        self.top_categories = top_categories
        self.id_cols = id_cols

    # --------------------------------------------------------------------- schema learning
    @classmethod
    def from_data(cls, X: pd.DataFrame, max_categories: int = 30, flag_threshold: float = 0.05,
                  id_cols: Sequence[str] = ()) -> "FeatureEngineer":
        X = X.drop(columns=[c for c in id_cols if c in X.columns])
        flags = [c for c in X.columns
                 if not pd.api.types.is_datetime64_any_dtype(X[c]) and X[c].isna().mean() >= flag_threshold]
        tops = {}
        for c in X.columns:
            if is_text(X[c]) and X[c].nunique() > max_categories:
                tops[c] = X[c].value_counts().index[:max_categories].astype(str).tolist()
        return cls(missing_flag_cols=flags, top_categories=tops, id_cols=list(id_cols))

    def fit(self, X, y=None):
        self.input_columns_ = list(pd.DataFrame(X).columns)
        return self

    # --------------------------------------------------------------------- transformation
    def transform(self, X) -> pd.DataFrame:
        X = pd.DataFrame(X).copy()
        X = X.drop(columns=[c for c in self.id_cols if c in X.columns])
        cols = list(X.columns)
        new: dict[str, pd.Series] = {}

        # usage momentum: <stem>_recent vs <stem>_prior  ->  relative change
        for c in cols:
            m = _RECENT_PRIOR.match(c)
            if m and f"{m['stem']}_prior" in X.columns:
                r, p = X[c], X[f"{m['stem']}_prior"]
                new[f"{m['stem']}_trend"] = _safe_div(r - p, p.abs() + 1.0)

        seats = "seats" if "seats" in X.columns else None
        if seats:
            for stem in ("logins", "minutes"):
                if f"{stem}_recent" in X.columns:
                    new[f"{stem}_per_seat"] = _safe_div(X[f"{stem}_recent"], X[seats])
            if "monthly_price" in X.columns:
                new["price_per_seat"] = _safe_div(X["monthly_price"], X[seats])

        if "tenure_days" in X.columns:
            months = X["tenure_days"] / 30.4
            new["tenure_months"] = months
            new["is_new_customer"] = (X["tenure_days"] <= 90).astype(int)
            if "tickets_total" in X.columns:
                new["tickets_per_month"] = _safe_div(X["tickets_total"], months.clip(lower=1))
        if {"tickets_total", "high_priority_tickets"} <= set(cols):
            new["high_priority_share"] = _safe_div(X["high_priority_tickets"], X["tickets_total"] + 1)
        if {"failed_payments", "late_payments", "payments_total"} <= set(cols):
            new["payment_issue_rate"] = _safe_div(X["failed_payments"] + X["late_payments"], X["payments_total"])

        # Telco-style columns: tenure + monthly + total charges
        ten = "tenure" if "tenure" in X.columns else _find(cols, "tenure", "month")
        mon = _find(cols, "monthly", "charge") or _find(cols, "monthly", "fee") or _find(cols, "monthly", "bill")
        tot = _find(cols, "total", "charge")
        if ten and mon and tot and all(pd.api.types.is_numeric_dtype(X[c]) for c in (ten, mon, tot)):
            avg = _safe_div(X[tot], X[ten] + 1)
            new["avg_monthly_spend"] = avg
            new["charge_vs_history"] = _safe_div(X[mon], avg)

        # dates: raw dates are dropped.  Calendar features (month/year) are deliberately NOT created -
        # combined with tenure they can reconstruct the churn date and leak the label.  Only
        # "days since" for last_*/recent_* style columns (recency) is kept.
        date_cols = [c for c in cols if pd.api.types.is_datetime64_any_dtype(X[c])]
        for c in date_cols:
            if any(k in c.lower() for k in ("last", "recent", "latest")):
                ref = X[c].max()
                new[f"{c}_days_since"] = (ref - X[c]).dt.days.astype(float)
        X = X.drop(columns=date_cols)

        # informative missingness
        for c in self.missing_flag_cols:
            if c in X.columns:
                new[f"{c}_missing"] = X[c].isna().astype(int)

        if new:
            X = pd.concat([X, pd.DataFrame(new, index=X.index)], axis=1)

        # types: bool -> int, text -> cleaned categories (+ "Other" for rare, "Missing" for NaN)
        for c in X.columns:
            s = X[c]
            if pd.api.types.is_bool_dtype(s):
                X[c] = s.astype(int)
            elif is_text(s):
                s = s.astype("object").where(s.notna(), "Missing").map(_clean_label)
                tops = (self.top_categories or {}).get(c)
                if tops is not None:
                    keep = {_clean_label(t) for t in tops}
                    s = s.where(s.isin(keep | {"Missing"}), "Other")
                X[c] = s
        X.columns = [re.sub(r"[^0-9A-Za-z_]+", "_", str(c)) for c in X.columns]
        return X


def build_pipeline(estimator, X: pd.DataFrame, scale: bool = False, id_cols: Sequence[str] = ()) -> Pipeline:
    """FeatureEngineer -> ColumnTransformer(impute/scale + one-hot) -> estimator."""
    fe = FeatureEngineer.from_data(X, id_cols=id_cols)
    Xf = fe.fit(X).transform(X)
    cat_cols = [c for c in Xf.columns if is_text(Xf[c])]
    num_cols = [c for c in Xf.columns if c not in cat_cols]
    cats = [sorted(Xf[c].astype(str).unique().tolist()) for c in cat_cols]

    steps = [("impute", SimpleImputer(strategy="median", keep_empty_features=True))]
    if scale:
        steps.append(("scale", StandardScaler()))
    transformers = [("num", Pipeline(steps), num_cols)]
    if cat_cols:
        transformers.append(("cat", OneHotEncoder(categories=cats, handle_unknown="ignore", drop="if_binary",
                                                  sparse_output=False, dtype=np.float32), cat_cols))
    prep = ColumnTransformer(transformers, verbose_feature_names_out=False)
    prep.set_output(transform="pandas")
    return Pipeline([("fe", fe), ("prep", prep), ("model", estimator)])


def feature_metadata(pipe: Pipeline) -> pd.DataFrame:
    """Map every model input column back to its source column / category."""
    prep: ColumnTransformer = pipe.named_steps["prep"]
    names = list(prep.get_feature_names_out())
    cat_cols = list(prep.transformers_[1][2]) if len(prep.transformers_) > 1 and prep.transformers_[1][0] == "cat" else []
    rows = []
    for n in names:
        src, cat, kind = n, None, "numeric"
        for c in sorted(cat_cols, key=len, reverse=True):
            if n.startswith(c + "_"):
                src, cat, kind = c, n[len(c) + 1:], "category"
                break
        rows.append({"feature": n, "source": src, "category": cat, "kind": kind})
    return pd.DataFrame(rows)
