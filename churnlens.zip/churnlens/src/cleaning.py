"""Automatic, fully-reported data cleaning for any tabular churn dataset.

Every transformation is logged as a :class:`CleaningStep` so the dashboard can
show exactly what changed and why.  Imputation is deliberately *not* done here -
it lives inside the model pipeline so it is fitted per CV fold (no leakage).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .config import ID_COL, TARGET

_MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "?", "-", "--", "missing", "#n/a"}
_ALIASES = {"usa": "united states", "us": "united states", "u.s.": "united states", "u.s.a.": "united states",
            "uk": "united kingdom", "u.k.": "united kingdom", "great britain": "united kingdom"}
_DATE_RE = re.compile(r"^\s*(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4})")


def is_text(s: pd.Series) -> bool:
    """True for object / string / category columns (pandas 2 and 3 compatible)."""
    return (pd.api.types.is_object_dtype(s) or pd.api.types.is_string_dtype(s)
            or isinstance(s.dtype, pd.CategoricalDtype))


@dataclass
class CleaningStep:
    step: str
    detail: str
    affected: int
    kind: str = "fix"          # fix | drop | info


@dataclass
class CleaningReport:
    steps: list[CleaningStep] = field(default_factory=list)
    rows_before: int = 0
    rows_after: int = 0
    cols_before: int = 0
    cols_after: int = 0
    missing_before: int = 0
    missing_after: int = 0
    missing_by_col: pd.Series | None = None

    def add(self, step: str, detail: str, affected: int, kind: str = "fix") -> None:
        if affected > 0 or kind == "info":
            self.steps.append(CleaningStep(step, detail, int(affected), kind))

    def to_frame(self) -> pd.DataFrame:
        return pd.DataFrame([s.__dict__ for s in self.steps], columns=["step", "detail", "affected", "kind"])


def to_snake(name: object) -> str:
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", str(name).strip())      # camelCase -> camel_Case
    s = re.sub(r"[^0-9a-zA-Z]+", "_", s).strip("_").lower()
    return s or "col"


def clean_dataframe(df: pd.DataFrame, target: str = TARGET, id_col: str = ID_COL
                    ) -> tuple[pd.DataFrame, CleaningReport]:
    rep = CleaningReport(rows_before=len(df), cols_before=df.shape[1], missing_before=int(df.isna().sum().sum()))
    df = df.copy()
    protected = {target, id_col}

    # 1 ── tidy column names -------------------------------------------------------------
    new_names, seen = [], {}
    for c in df.columns:
        n = c if c in protected else to_snake(c)
        seen[n] = seen.get(n, 0) + 1
        new_names.append(n if seen[n] == 1 else f"{n}_{seen[n]}")
    renamed = sum(a != b for a, b in zip(df.columns, new_names))
    df.columns = new_names
    rep.add("Standardise column names", "snake_case, unique names", renamed)

    text_cols = [c for c in df.columns if is_text(df[c]) and c not in protected]

    # 2 ── strip whitespace + unify missing tokens ---------------------------------------
    stripped = filled = 0
    for c in text_cols:
        s = df[c].astype("object")
        mask = s.notna()
        trimmed = s[mask].astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
        stripped += int((trimmed != s[mask].astype(str)).sum())
        s[mask] = trimmed
        is_tok = s.notna() & s.astype(str).str.lower().isin(_MISSING_TOKENS)
        filled += int(is_tok.sum())
        s[is_tok] = np.nan
        df[c] = s
    rep.add("Trim whitespace", "Leading/trailing/duplicate spaces in text values", stripped)
    rep.add("Unify missing tokens", "'', 'N/A', 'null', '?' ... converted to real missing values", filled)

    # 3 ── duplicates ---------------------------------------------------------------------
    n0 = len(df)
    df = df.drop_duplicates()
    rep.add("Remove duplicate rows", "Exact duplicate records", n0 - len(df), "drop")
    n0 = len(df)
    if id_col in df.columns:
        df = df.drop_duplicates(subset=[id_col], keep="first")
        rep.add("Remove duplicate customers", f"Repeated `{id_col}` values (kept first)", n0 - len(df), "drop")

    # 4 ── numbers hidden in text ---------------------------------------------------------
    coerced = []
    for c in [c for c in text_cols if c in df.columns]:
        s = df[c]
        nn = s.dropna()
        if nn.empty:
            continue
        cleaned = nn.astype(str).str.replace(r"[,$€£%\s]", "", regex=True)
        parsed = pd.to_numeric(cleaned, errors="coerce")
        if parsed.notna().mean() >= 0.90:
            full = pd.Series(np.nan, index=df.index)
            full.loc[nn.index] = parsed
            df[c] = full
            coerced.append(c)
    rep.add("Convert numeric text", f"Columns stored as text but numeric: {', '.join(coerced[:6])}", len(coerced))

    # 5 ── dates ----------------------------------------------------------------------------
    parsed_dates = []
    for c in [c for c in text_cols if c in df.columns and is_text(df[c])]:
        sample = df[c].dropna().astype(str).head(60)
        if len(sample) and sample.map(lambda v: bool(_DATE_RE.match(v))).mean() >= 0.9:
            parsed = pd.to_datetime(df[c], errors="coerce", format="mixed")
            if parsed.notna().mean() >= 0.9:
                df[c] = parsed
                parsed_dates.append(c)
    rep.add("Parse dates", f"Text → datetime: {', '.join(parsed_dates)}", len(parsed_dates))

    # 6 ── inconsistent categories ----------------------------------------------------------
    unified = 0
    for c in [c for c in text_cols if c in df.columns and is_text(df[c])]:
        s = df[c].astype("object")
        mask = s.notna()
        if not mask.any():
            continue
        low = s[mask].astype(str).str.lower()
        if "country" in c:
            low = low.replace(_ALIASES)
        canon = {}
        for key, grp in pd.DataFrame({"k": low, "orig": s[mask].astype(str)}).groupby("k"):
            canon[key] = grp["orig"].value_counts().index[0]
        new = low.map(canon)
        if "country" in c:                                    # aliases map onto an existing spelling
            new = new.fillna(low)
        unified += int((new != s[mask].astype(str)).sum())
        s[mask] = new
        df[c] = s
    rep.add("Unify category labels", "Case variants and aliases (e.g. 'growth' → 'Growth', 'USA' → 'United States')", unified)

    numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c]) and c not in protected
                    and not pd.api.types.is_bool_dtype(df[c])]

    # 7 ── impossible values ------------------------------------------------------------------
    bad = 0
    details = []
    for c in numeric_cols:
        s = df[c]
        nn = s.dropna()
        if nn.nunique() <= 2 or nn.empty:
            continue
        cnt = 0
        if re.search(r"(^|_)age($|_)", c):
            m = (s < 10) | (s > 100)
            cnt = int(m.sum())
            df.loc[m, c] = np.nan
        elif (nn >= 0).mean() >= 0.98 and (nn < 0).any():
            m = s < 0
            cnt = int(m.sum())
            df.loc[m, c] = np.nan
        if cnt:
            bad += cnt
            details.append(f"{c} ({cnt})")
    rep.add("Null impossible values", "Negative amounts/counts and out-of-range ages → missing: " + ", ".join(details[:6]), bad)

    # 8 ── extreme outliers (winsorise only when they are genuinely rare) -------------------------
    clipped, cols = 0, []
    for c in numeric_cols:
        s = df[c]
        if s.nunique() < 20:
            continue
        q1, q3 = s.quantile([0.25, 0.75])
        iqr = q3 - q1
        if iqr <= 0:
            continue
        lo, hi = q1 - 4 * iqr, q3 + 4 * iqr
        m = (s < lo) | (s > hi)
        if 0 < m.sum() <= 0.01 * len(s):
            df[c] = s.clip(lo, hi)
            clipped += int(m.sum())
            cols.append(c)
    rep.add("Winsorise extreme outliers", f"Clipped beyond 4×IQR fences in: {', '.join(cols[:6])}", clipped)

    # 9 ── useless columns ---------------------------------------------------------------------------
    drops = []
    for c in list(df.columns):
        if c in protected:
            continue
        s = df[c]
        if s.isna().mean() > 0.60:
            drops.append((c, ">60% missing"))
        elif s.nunique(dropna=True) <= 1:
            drops.append((c, "constant"))
        elif is_text(s) and s.nunique() > 50 and s.nunique() / max(len(s), 1) > 0.90:
            drops.append((c, "identifier-like text"))
    for c, why in drops:
        df = df.drop(columns=c)
        rep.add("Drop column", f"`{c}`: {why}", 1, "drop")

    # 10 ── label hygiene --------------------------------------------------------------------------------
    n0 = len(df)
    df = df[df[target].notna()].copy()
    df[target] = df[target].astype(int)
    rep.add("Drop rows without a label", "Missing churn value", n0 - len(df), "drop")

    df = df.reset_index(drop=True)
    rep.rows_after, rep.cols_after = len(df), df.shape[1]
    rep.missing_after = int(df.isna().sum().sum())
    rep.missing_by_col = df.isna().sum().loc[lambda s: s > 0].sort_values(ascending=False)
    rep.add("Missing values kept", "Imputed inside the model pipeline (per CV fold) to avoid leakage",
            rep.missing_after, "info")
    return df, rep
