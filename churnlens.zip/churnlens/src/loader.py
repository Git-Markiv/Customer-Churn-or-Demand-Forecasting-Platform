"""Custom dataset ingestion: reading files, detecting the churn column, standardising the label."""
from __future__ import annotations

import io
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import ID_COL, TARGET

_POSITIVE_TOKENS = {"1", "yes", "y", "true", "t", "churn", "churned", "left", "exited", "cancelled",
                    "canceled", "attrited", "attrited customer", "closed", "lost", "inactive"}
_TARGET_HINTS = ("churn", "attrition", "exited", "cancel", "left", "defect", "target", "label")
_ID_HINTS = ("customer_id", "customerid", "cust_id", "user_id", "userid", "account_id", "client_id", "id")
_REVENUE_HINTS = ("monthly_price", "monthlycharges", "monthly_charges", "monthly_charge", "mrr", "arpu",
                  "revenue", "amount", "price", "spend", "charges", "balance")


def read_table(source: Any, filename: str | None = None) -> pd.DataFrame:
    """Read CSV / TSV / Excel / JSON / Parquet from a path, bytes or an uploaded file object."""
    name = (filename or getattr(source, "name", None) or str(source)).lower()
    if isinstance(source, (str, Path)):
        buf: Any = source
    else:
        raw = source.getvalue() if hasattr(source, "getvalue") else source.read()
        buf = io.BytesIO(raw)

    def _rewind() -> None:
        if hasattr(buf, "seek"):
            buf.seek(0)

    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(buf)
    if name.endswith(".json"):
        return pd.read_json(buf)
    if name.endswith(".parquet"):
        return pd.read_parquet(buf)

    last_err: Exception | None = None
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            _rewind()
            df = pd.read_csv(buf, encoding=enc)
            if df.shape[1] == 1:                                   # wrong delimiter? sniff it
                _rewind()
                df = pd.read_csv(buf, encoding=enc, sep=None, engine="python")
            return df
        except UnicodeDecodeError as err:
            last_err = err
    raise ValueError(f"Could not decode the file: {last_err}")


def suggest_target(df: pd.DataFrame) -> str | None:
    cols = list(df.columns)
    for hint in _TARGET_HINTS:
        for c in cols:
            if hint in str(c).lower() and 2 <= df[c].nunique(dropna=True) <= 10:
                return c
    binary = [c for c in cols if df[c].nunique(dropna=True) == 2]
    return binary[-1] if binary else None


def suggest_id(df: pd.DataFrame) -> str | None:
    for hint in _ID_HINTS:
        for c in df.columns:
            if str(c).lower().replace(" ", "_") == hint and df[c].nunique() >= 0.9 * len(df):
                return c
    for c in df.columns:
        if df[c].nunique() == len(df) and not pd.api.types.is_float_dtype(df[c]):
            return c
    return None


def suggest_revenue(df: pd.DataFrame) -> str | None:
    numeric = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    for hint in _REVENUE_HINTS:
        for c in numeric:
            if hint in str(c).lower().replace(" ", "_"):
                return c
    return None


def suggest_positive_value(values: list[Any]) -> Any:
    for v in values:
        if str(v).strip().lower() in _POSITIVE_TOKENS:
            return v
    return values[-1] if values else None


def standardize_target(series: pd.Series, positive_value: Any) -> pd.Series:
    """Map the chosen column to 0/1 where `positive_value` means "churned"."""
    s = series.copy()
    pos = str(positive_value).strip().lower()
    out = s.astype(str).str.strip().str.lower().eq(pos).astype(float)
    out[s.isna()] = np.nan
    return out


def prepare_custom_frame(df: pd.DataFrame, target_col: str, positive_value: Any,
                         id_col: str | None = None, revenue_col: str | None = None
                         ) -> pd.DataFrame:
    """Rename the user's target / id / revenue columns to ChurnLens' internal names.

    Any pre-existing column that collides with an internal name is kept as `<name>_orig`.
    """
    df = df.copy()
    df["__target__"] = standardize_target(df[target_col], positive_value)
    df = df.drop(columns=[target_col])
    # free the internal names if the user's data already uses them for something else
    for internal in (TARGET, ID_COL):
        if internal in df.columns and internal != id_col:
            df = df.rename(columns={internal: f"{internal}_orig"})
    df = df.rename(columns={"__target__": TARGET})
    if id_col:
        if id_col != ID_COL:
            df = df.rename(columns={id_col: ID_COL})
    else:
        df.insert(0, ID_COL, [f"ROW-{i + 1}" for i in range(len(df))])
    return df
