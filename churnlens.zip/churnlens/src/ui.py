"""Premium dark UI layer: CSS theme, animations and small HTML components for Streamlit."""
from __future__ import annotations

import html as _html

import streamlit as st

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');

:root{
  --bg:#070912; --panel:#0f1324; --panel2:#151a31; --line:rgba(255,255,255,.08); --line2:rgba(255,255,255,.14);
  --text:#e8ebf7; --muted:#8f97b8; --violet:#8b5cf6; --indigo:#6366f1; --cyan:#22d3ee; --emerald:#34d399;
  --amber:#fbbf24; --rose:#fb7185; --ease:cubic-bezier(.2,.7,.2,1);
}
html, body, [class*="css"], .stApp, .stMarkdown, button, input, textarea, select {
  font-family:'Inter',system-ui,-apple-system,'Segoe UI',sans-serif !important;
}
code, pre, .mono {font-family:'JetBrains Mono',ui-monospace,Menlo,Consolas,monospace !important;}

/* ---------- canvas + ambient orbs ---------- */
.stApp{
  background:
    radial-gradient(1100px 600px at 12% -10%, rgba(139,92,246,.20), transparent 60%),
    radial-gradient(900px 520px at 100% 0%, rgba(34,211,238,.13), transparent 55%),
    radial-gradient(900px 700px at 50% 120%, rgba(99,102,241,.14), transparent 60%),
    var(--bg);
  color:var(--text);
}
.stApp::before, .stApp::after{
  content:""; position:fixed; z-index:0; border-radius:50%; filter:blur(90px); pointer-events:none; opacity:.35;
}
.stApp::before{width:420px;height:420px;left:-120px;top:30vh;background:#6d4af0;animation:drift1 22s ease-in-out infinite;}
.stApp::after{width:380px;height:380px;right:-100px;top:8vh;background:#0fb5cf;animation:drift2 26s ease-in-out infinite;}
@keyframes drift1{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(90px,-60px) scale(1.15)}}
@keyframes drift2{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(-80px,70px) scale(1.1)}}

header[data-testid="stHeader"]{background:transparent;}
#MainMenu, footer, [data-testid="stDecoration"]{visibility:hidden;height:0;}
.block-container{padding-top:1.6rem; padding-bottom:4rem; max-width:1320px; position:relative; z-index:1;}
h1,h2,h3,h4{letter-spacing:-.02em; color:var(--text);}
p, li, label, .stMarkdown{color:var(--text);}
a{color:var(--cyan) !important; text-decoration:none;}
hr{border-color:var(--line) !important;}

/* ---------- keyframes ---------- */
@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes shimmer{to{background-position:200% center}}
@keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(52,211,153,.55)}70%{box-shadow:0 0 0 9px rgba(52,211,153,0)}}
@keyframes growX{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes sweep{0%{transform:translateX(-120%)}100%{transform:translateX(220%)}}
@keyframes floaty{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}

@property --n{syntax:'<integer>';inherits:false;initial-value:0}
@property --f{syntax:'<integer>';inherits:false;initial-value:0}
@keyframes countup{from{--n:0;--f:0}}

.stTabs [data-baseweb="tab-panel"]{animation:fadeUp .55s var(--ease) both; padding-top:1.1rem;}
.stPlotlyChart, [data-testid="stDataFrame"], [data-testid="stPlotlyChart"]{animation:fadeUp .7s var(--ease) both;}
[data-testid="stVerticalBlockBorderWrapper"]{animation:fadeIn .6s ease both;}

/* ---------- hero ---------- */
.hero{position:relative; padding:34px 38px; border-radius:24px; overflow:hidden;
  background:linear-gradient(135deg, rgba(139,92,246,.16), rgba(34,211,238,.07) 55%, rgba(15,19,36,.6));
  border:1px solid var(--line2); backdrop-filter:blur(14px); animation:fadeUp .8s var(--ease) both; margin-bottom:22px;}
.hero::after{content:""; position:absolute; inset:0; background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,.07) 50%,transparent 65%);
  width:50%; animation:sweep 7s ease-in-out infinite; pointer-events:none;}
.hero .eyebrow{display:inline-flex; gap:8px; align-items:center; font-size:12px; letter-spacing:.14em; text-transform:uppercase;
  color:var(--muted); font-weight:600;}
.hero .dot{width:8px;height:8px;border-radius:50%;background:var(--emerald); animation:pulse 2s infinite;}
.hero h1{font-size:clamp(34px,5vw,56px); font-weight:800; line-height:1.04; margin:12px 0 10px;
  background:linear-gradient(92deg,#fff 0%,#c4b5fd 35%,#67e8f9 70%,#fff 100%); background-size:200% auto;
  -webkit-background-clip:text; background-clip:text; color:transparent; animation:shimmer 7s linear infinite;}
.hero p{max-width:760px; color:var(--muted); font-size:16px; line-height:1.6; margin:0;}
.hero .chips{display:flex; flex-wrap:wrap; gap:8px; margin-top:20px;}

.chip{display:inline-flex; align-items:center; gap:6px; padding:5px 12px; border-radius:999px; font-size:12px; font-weight:500;
  color:var(--text); background:rgba(255,255,255,.05); border:1px solid var(--line); transition:all .25s var(--ease);}
.chip:hover{transform:translateY(-2px); border-color:var(--line2); background:rgba(255,255,255,.09);}
.chip b{color:var(--cyan); font-weight:600;}

/* ---------- section headings ---------- */
.sec{margin:6px 0 14px; animation:fadeUp .6s var(--ease) both;}
.sec .t{font-size:20px; font-weight:700; letter-spacing:-.01em;}
.sec .s{color:var(--muted); font-size:13.5px; margin-top:3px; max-width:880px; line-height:1.55;}
.sec .bar{height:3px; width:44px; border-radius:3px; margin-bottom:10px;
  background:linear-gradient(90deg,var(--violet),var(--cyan)); transform-origin:left; animation:growX .8s var(--ease) both;}

/* ---------- KPI cards ---------- */
.kpis{display:grid; grid-template-columns:repeat(auto-fit,minmax(165px,1fr)); gap:14px; margin:6px 0 18px;}
.kpi{position:relative; padding:18px 20px; border-radius:18px; background:linear-gradient(160deg,rgba(255,255,255,.055),rgba(255,255,255,.02));
  border:1px solid var(--line); backdrop-filter:blur(10px); overflow:hidden;
  animation:fadeUp .7s var(--ease) both; animation-delay:var(--d,0s); transition:transform .3s var(--ease), border-color .3s, box-shadow .3s;}
.kpi:hover{transform:translateY(-4px); border-color:var(--line2); box-shadow:0 14px 40px -12px var(--glow, rgba(139,92,246,.45));}
.kpi::before{content:""; position:absolute; left:0; top:0; height:100%; width:3px; background:var(--accent,var(--violet)); opacity:.9;}
.kpi .l{font-size:12px; color:var(--muted); letter-spacing:.06em; text-transform:uppercase; font-weight:600;}
.kpi .v{font-size:32px; font-weight:750; letter-spacing:-.02em; margin-top:6px; display:flex; align-items:baseline; gap:2px; line-height:1.1;}
.kpi .v small{font-size:15px; color:var(--muted); font-weight:500; margin-left:2px;}
.kpi .d{font-size:12px; color:var(--muted); margin-top:6px;}
.count{--n:var(--ti); --f:var(--tf); counter-reset:ni var(--n) nf var(--f); animation:countup 1.3s var(--ease) both; animation-delay:var(--d,0s);}
.count::after{content:counter(ni);}
.count.d2::after{content:counter(ni) "." counter(nf, decimal-leading-zero);}
.count.d1::after{content:counter(ni) "." counter(nf);}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0);}

/* ---------- panels / callouts ---------- */
.panel{padding:18px 20px; border-radius:18px; background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.015));
  border:1px solid var(--line); animation:fadeUp .7s var(--ease) both;}
.callout{display:flex; gap:12px; padding:14px 16px; border-radius:14px; border:1px solid var(--line); font-size:13.5px; line-height:1.55;
  background:rgba(255,255,255,.035); animation:fadeUp .6s var(--ease) both; margin:8px 0;}
.callout .ic{font-size:16px; line-height:1.4;}
.callout.good{border-color:rgba(52,211,153,.35); background:rgba(52,211,153,.07);}
.callout.warn{border-color:rgba(251,191,36,.35); background:rgba(251,191,36,.07);}
.callout.bad{border-color:rgba(251,113,133,.35); background:rgba(251,113,133,.07);}
.callout.info{border-color:rgba(34,211,238,.30); background:rgba(34,211,238,.06);}

/* ---------- pipeline steps ---------- */
.steps{display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin:10px 0 4px;}
.step{padding:12px 14px; border-radius:14px; border:1px solid var(--line); background:rgba(255,255,255,.03);
  animation:fadeUp .6s var(--ease) both; animation-delay:var(--d,0s);}
.step .n{font-size:11px; color:var(--cyan); font-weight:700; letter-spacing:.1em;}
.step .h{font-size:14px; font-weight:600; margin-top:3px;}
.step .p{font-size:12px; color:var(--muted); margin-top:3px; line-height:1.4;}

/* ---------- gauge ---------- */
.gauge{position:relative; width:200px; height:200px; margin:0 auto; animation:fadeIn .8s ease both;}
.gauge svg{transform:rotate(-90deg); width:100%; height:100%;}
.gauge .track{stroke:rgba(255,255,255,.08);}
.gauge .arc{stroke-linecap:round; stroke-dasharray:var(--len) 999; stroke-dashoffset:0; animation:gaugeIn 1.4s var(--ease) both;
  filter:drop-shadow(0 0 8px var(--c));}
@keyframes gaugeIn{from{stroke-dasharray:0 999}}
.gauge .mid{position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center;}
.gauge .pct{font-size:42px; font-weight:800; letter-spacing:-.03em;}
.gauge .band{font-size:12px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; margin-top:2px;}

/* ---------- driver rows ---------- */
.drv{display:grid; grid-template-columns:minmax(0,1.5fr) minmax(0,1fr) minmax(0,1.6fr); gap:12px; align-items:center;
  padding:9px 0; border-bottom:1px solid var(--line); animation:fadeUp .5s var(--ease) both; animation-delay:var(--d,0s);}
.drv:last-child{border-bottom:none;}
.drv .nm{font-size:13.5px; font-weight:500;}
.drv .vl{font-size:12.5px; color:var(--muted); font-family:'JetBrains Mono',monospace;}
.drv .track{height:8px; border-radius:6px; background:rgba(255,255,255,.06); position:relative; overflow:hidden;}
.drv .fill{position:absolute; top:0; bottom:0; border-radius:6px; transform-origin:left; animation:growX .9s var(--ease) both; animation-delay:var(--d,0s);}
.drv .imp{font-size:11.5px; color:var(--muted); text-align:right; margin-top:3px;}

.badge{display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; letter-spacing:.08em; text-transform:uppercase;}
.play{display:flex; gap:12px; align-items:flex-start; padding:12px 14px; border-radius:14px; background:rgba(255,255,255,.04);
  border:1px solid var(--line); margin-bottom:8px; animation:fadeUp .6s var(--ease) both; animation-delay:var(--d,0s); transition:transform .25s var(--ease), border-color .25s;}
.play:hover{transform:translateX(4px); border-color:rgba(34,211,238,.4);}
.play .num{min-width:26px;height:26px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;
  background:linear-gradient(135deg,var(--violet),var(--cyan)); color:#071018;}
.play .why{font-size:11.5px; color:var(--muted); margin-bottom:2px;}

/* ---------- streamlit widgets ---------- */
section[data-testid="stSidebar"]{background:linear-gradient(180deg,#0b0f20,#080b17); border-right:1px solid var(--line);}
section[data-testid="stSidebar"] .block-container{padding-top:1rem;}
.brand{display:flex; align-items:center; gap:10px; margin:2px 0 14px;}
.brand .logo{width:36px;height:36px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#06101a;
  background:linear-gradient(135deg,var(--violet),var(--cyan)); box-shadow:0 8px 24px -8px var(--violet); animation:floaty 5s ease-in-out infinite;}
.brand .name{font-size:18px;font-weight:750;letter-spacing:-.02em;}
.brand .tag{font-size:11px;color:var(--muted);margin-top:-2px;}

.stButton > button, .stDownloadButton > button, [data-testid="stFormSubmitButton"] > button{
  border-radius:12px; border:1px solid var(--line2); font-weight:600; color:var(--text);
  background:rgba(255,255,255,.05); transition:all .25s var(--ease);}
.stButton > button:hover, .stDownloadButton > button:hover{transform:translateY(-2px); border-color:var(--cyan); color:#fff;
  box-shadow:0 10px 30px -10px rgba(34,211,238,.5);}
.stButton > button[kind="primary"], [data-testid="stBaseButton-primary"]{
  background:linear-gradient(110deg,#7c4dff,#4f7bff 50%,#22d3ee); background-size:180% auto; border:none; color:#fff;
  box-shadow:0 10px 30px -10px rgba(124,77,255,.8); transition:all .35s var(--ease);}
.stButton > button[kind="primary"]:hover, [data-testid="stBaseButton-primary"]:hover{background-position:right center; transform:translateY(-2px) scale(1.015);
  box-shadow:0 16px 40px -10px rgba(99,102,241,.9); color:#fff;}
.stButton > button:active{transform:scale(.98);}

.stTabs [data-baseweb="tab-list"]{gap:6px; padding:5px; border-radius:16px; background:rgba(255,255,255,.04); border:1px solid var(--line);
  width:fit-content; max-width:100%; overflow-x:auto;}
.stTabs [data-baseweb="tab"]{height:40px; padding:0 18px; border-radius:12px; color:var(--muted); font-weight:600; font-size:14px;
  background:transparent; transition:all .25s var(--ease);}
.stTabs [data-baseweb="tab"]:hover{color:var(--text); background:rgba(255,255,255,.06);}
.stTabs [aria-selected="true"]{color:#fff !important; background:linear-gradient(135deg,rgba(139,92,246,.55),rgba(34,211,238,.28)) !important;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.14), 0 8px 22px -10px rgba(139,92,246,.9);}
.stTabs [data-baseweb="tab-highlight"], .stTabs [data-baseweb="tab-border"]{display:none;}

[data-baseweb="select"] > div, .stTextInput input, .stNumberInput input, .stTextArea textarea, [data-baseweb="input"]{
  background:rgba(255,255,255,.04) !important; border-color:var(--line) !important; border-radius:12px !important; color:var(--text);}
[data-baseweb="select"] > div:hover, .stTextInput input:focus, .stTextArea textarea:focus{border-color:rgba(34,211,238,.55) !important;}
.stTextArea textarea{font-family:'JetBrains Mono',monospace !important; font-size:13px;}
[data-testid="stFileUploader"] section{border:1.5px dashed rgba(139,92,246,.5); border-radius:16px; background:rgba(139,92,246,.06); transition:all .3s;}
[data-testid="stFileUploader"] section:hover{border-color:var(--cyan); background:rgba(34,211,238,.07);}
[data-testid="stExpander"]{border:1px solid var(--line) !important; border-radius:14px !important; background:rgba(255,255,255,.025);}
[data-testid="stExpander"] summary:hover{color:var(--cyan);}
[data-testid="stDataFrame"]{border:1px solid var(--line); border-radius:14px; overflow:hidden;}
[data-testid="stMetric"]{background:rgba(255,255,255,.04); border:1px solid var(--line); border-radius:14px; padding:12px 16px;}
.stProgress > div > div > div > div{background:linear-gradient(90deg,var(--violet),var(--cyan)); border-radius:8px;}
.stSlider [data-baseweb="slider"] div[role="slider"]{box-shadow:0 0 0 6px rgba(34,211,238,.18);}
[data-testid="stSidebar"] .stRadio label{padding:2px 0;}
.stCaption, [data-testid="stCaptionContainer"]{color:var(--muted) !important;}
::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-thumb{background:rgba(255,255,255,.14);border-radius:8px}
::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,.24)}

@media (prefers-reduced-motion: reduce){
  *, *::before, *::after{animation-duration:.01ms !important; animation-iteration-count:1 !important; transition-duration:.01ms !important;}
}
@media (max-width:760px){
  .hero{padding:24px 20px;} .drv{grid-template-columns:1fr; gap:4px;}
}
</style>
"""


def _flat(html: str) -> str:
    """Collapse indentation so Streamlit's markdown never treats HTML as a code block."""
    return "".join(line.strip() for line in html.strip().splitlines())


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def html(markup: str) -> None:
    st.markdown(_flat(markup), unsafe_allow_html=True)


def esc(x: object) -> str:
    return _html.escape(str(x))


# ------------------------------------------------------------------------------ components
def hero(title: str, subtitle: str, chips: list[tuple[str, str]], eyebrow: str = "Customer churn intelligence") -> None:
    chip_html = "".join(f'<span class="chip">{esc(k)} <b>{esc(v)}</b></span>' for k, v in chips)
    html(f"""<div class="hero"><div class="eyebrow"><span class="dot"></span>{esc(eyebrow)}</div>
    <h1>{esc(title)}</h1><p>{esc(subtitle)}</p><div class="chips">{chip_html}</div></div>""")


def section(title: str, subtitle: str = "") -> None:
    sub = f'<div class="s">{subtitle}</div>' if subtitle else ""
    html(f'<div class="sec"><div class="bar"></div><div class="t">{esc(title)}</div>{sub}</div>')


def kpi_html(label: str, value: float, decimals: int = 0, prefix: str = "", suffix: str = "", note: str = "",
             accent: str = "#8b5cf6", delay: float = 0.0) -> str:
    """One animated KPI card. The number counts up from 0 using CSS @property (Chromium/Safari/Firefox 128+)."""
    value = float(value)
    scale = 10 ** decimals
    total = int(round(abs(value) * scale))
    ti, tf = divmod(total, scale) if decimals else (total, 0)
    sign = "-" if value < 0 else ""
    cls = {0: "count", 1: "count d1", 2: "count d2"}.get(decimals, "count")
    shown = f"{value:,.{decimals}f}"
    return (f'<div class="kpi" style="--accent:{accent};--glow:{accent}66;--d:{delay}s">'
            f'<div class="l">{esc(label)}</div>'
            f'<div class="v">{esc(prefix)}{sign}<span class="{cls}" style="--ti:{ti};--tf:{tf};--d:{delay + .1}s">'
            f'<span class="sr">{esc(shown)}</span></span><small>{esc(suffix)}</small></div>'
            f'<div class="d">{esc(note)}</div></div>')


def kpi_row(items: list[dict]) -> None:
    cards = "".join(kpi_html(delay=0.06 * i, **it) for i, it in enumerate(items))
    html(f'<div class="kpis">{cards}</div>')


def callout(text: str, kind: str = "info", icon: str | None = None) -> None:
    icons = {"info": "ℹ️", "good": "✅", "warn": "⚠️", "bad": "⛔"}
    html(f'<div class="callout {kind}"><div class="ic">{icon or icons.get(kind, "ℹ️")}</div><div>{text}</div></div>')


def steps(items: list[tuple[str, str]]) -> None:
    cards = "".join(f'<div class="step" style="--d:{0.06 * i}s"><div class="n">STEP {i + 1:02d}</div>'
                    f'<div class="h">{esc(h)}</div><div class="p">{esc(p)}</div></div>' for i, (h, p) in enumerate(items))
    html(f'<div class="steps">{cards}</div>')


def gauge(prob: float, band: str, color: str) -> None:
    r = 80
    circ = 2 * 3.14159265 * r
    length = max(0.0, min(prob, 1.0)) * circ
    html(f"""<div class="gauge" style="--c:{color};--len:{length:.1f}">
    <svg viewBox="0 0 200 200"><circle class="track" cx="100" cy="100" r="{r}" fill="none" stroke-width="14"/>
    <circle class="arc" cx="100" cy="100" r="{r}" fill="none" stroke-width="14" stroke="{color}"/></svg>
    <div class="mid"><div class="pct">{prob * 100:.0f}%</div><div class="band" style="color:{color}">{esc(band)} risk</div></div></div>""")


def driver_rows(rows: list[dict]) -> None:
    """rows: label, value, impact (signed log-odds / prob units)."""
    if not rows:
        return
    mx = max(abs(r["impact"]) for r in rows) or 1.0
    out = []
    for i, r in enumerate(rows):
        w = abs(r["impact"]) / mx * 100
        col = "#fb7185" if r["impact"] > 0 else "#34d399"
        out.append(f'<div class="drv" style="--d:{0.05 * i}s"><div class="nm">{esc(r["label"])}</div>'
                   f'<div class="vl">{esc(r["value"])}</div><div><div class="track"><div class="fill" '
                   f'style="left:0;width:{w:.1f}%;background:{col};--d:{0.05 * i + .15}s"></div></div>'
                   f'<div class="imp">{"▲" if r["impact"] > 0 else "▼"} {r["impact"]:+.3f}</div></div></div>')
    html(f'<div class="panel">{"".join(out)}</div>')


def play_cards(plays: list[tuple[str, str]]) -> None:
    out = "".join(f'<div class="play" style="--d:{0.08 * i}s"><div class="num">{i + 1}</div><div>'
                  f'<div class="why">Because of: {esc(why)}</div><div>{esc(txt)}</div></div></div>'
                  for i, (why, txt) in enumerate(plays))
    html(out)


def badge(text: str, color: str) -> str:
    return f'<span class="badge" style="color:{color};background:{color}22;border:1px solid {color}55">{esc(text)}</span>'


def brand() -> None:
    html('<div class="brand"><div class="logo">C</div><div><div class="name">ChurnLens</div>'
         '<div class="tag">Churn intelligence · SHAP explained</div></div></div>')
