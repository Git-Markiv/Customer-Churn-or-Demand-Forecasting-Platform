"""Turn model output into business language: labels, reasons, actions and retention ROI."""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

LABELS = {
    "logins_trend": "Login momentum", "minutes_trend": "Time-in-app momentum",
    "features_trend": "Feature-adoption momentum", "api_calls_trend": "API usage momentum",
    "logins_recent": "Logins / month (last 3 mo)", "logins_prior": "Logins / month (earlier)",
    "logins_last_month": "Logins last month", "minutes_recent": "Active minutes (last 3 mo)",
    "minutes_prior": "Active minutes (earlier)", "features_recent": "Features used (last 3 mo)",
    "features_prior": "Features used (earlier)", "api_calls_recent": "API calls (last 3 mo)",
    "api_calls_prior": "API calls (earlier)", "logins_per_seat": "Logins per seat",
    "minutes_per_seat": "Minutes per seat", "price_per_seat": "Price per seat",
    "tenure_days": "Tenure (days)", "tenure_months": "Tenure (months)", "is_new_customer": "New customer (<90 d)",
    "tickets_total": "Support tickets (total)", "tickets_90d": "Support tickets (last 90 d)",
    "tickets_per_month": "Tickets per month", "high_priority_tickets": "High-priority tickets",
    "high_priority_share": "High-priority ticket share", "avg_resolution_hours": "Avg ticket resolution (h)",
    "avg_csat": "Avg CSAT (1-5)", "failed_payments": "Failed payments", "late_payments": "Late payments",
    "payments_total": "Invoices issued", "payment_issue_rate": "Payment issue rate",
    "monthly_price": "Monthly price", "add_ons": "Add-ons", "autopay": "Autopay enabled", "seats": "Seats",
    "months_observed": "Months of usage history", "age": "Customer age",
    "acquisition_channel": "Acquisition channel", "contract_type": "Contract type",
    "payment_method": "Payment method", "company_size": "Company size", "avg_monthly_spend": "Avg monthly spend",
    "charge_vs_history": "Current charge vs history",
}

_ACTIONS = [
    (("contract", "term"), "Offer a discounted annual / multi-year upgrade to lock in commitment"),
    (("trend", "login", "minutes", "features", "api_calls", "usage", "active", "engag", "recent", "last_month"),
     "Trigger a re-engagement campaign and a customer-success check-in on usage"),
    (("ticket", "csat", "resolution", "support", "complaint", "priority"),
     "Escalate to priority support and close the loop on open issues"),
    (("payment", "failed", "late", "billing", "invoice"),
     "Fix billing friction: dunning flow, backup payment method, or invoice terms"),
    (("price", "charge", "spend", "monthly_price", "add_on"),
     "Review pricing fit: right-size the plan, offer a price-lock or bundle"),
    (("tenure", "new_customer", "months_observed"),
     "Strengthen onboarding with a guided setup and a 30-day success plan"),
    (("autopay",), "Encourage autopay enrolment with a small incentive"),
    (("channel", "company_size", "country", "gender", "age"),
     "Tailor messaging to this segment - it carries more churn risk than average"),
]


def pretty_name(feature: str, meta: pd.DataFrame | None = None) -> str:
    """Business-friendly label for a model input column."""
    if feature in LABELS:
        return LABELS[feature]
    if meta is not None:
        row = meta.loc[meta["feature"] == feature]
        if len(row) and row.iloc[0]["kind"] == "category":
            src, cat = row.iloc[0]["source"], row.iloc[0]["category"]
            return f"{LABELS.get(src, _tidy(src))}: {cat}"
    if feature.endswith("_missing"):
        return f"{pretty_name(feature[:-8])} is missing"
    return _tidy(feature)


def _tidy(s: str) -> str:
    s = re.sub(r"_+", " ", str(s)).strip()
    return s[:1].upper() + s[1:]


def format_value(feature: str, value: float, meta: pd.DataFrame | None = None) -> str:
    is_cat = False
    if meta is not None:
        row = meta.loc[meta["feature"] == feature]
        is_cat = bool(len(row) and row.iloc[0]["kind"] == "category")
    if is_cat:
        return "Yes" if value >= 0.5 else "No"
    if feature.endswith("_trend"):
        return f"{value * 100:+.0f}%"
    if feature in ("autopay", "is_new_customer") or feature.endswith("_missing"):
        return "Yes" if value >= 0.5 else "No"
    if abs(value) >= 1000:
        return f"{value:,.0f}"
    return f"{value:,.2f}".rstrip("0").rstrip(".")


def customer_reasons(sv: np.ndarray, row: pd.Series, meta: pd.DataFrame, k: int = 8) -> pd.DataFrame:
    order = np.argsort(-np.abs(sv))[:k]
    out = []
    for i in order:
        f = row.index[i]
        out.append({"feature": f, "label": pretty_name(f, meta), "value": format_value(f, float(row.iloc[i]), meta),
                    "impact": float(sv[i]), "effect": "Raises risk" if sv[i] > 0 else "Lowers risk"})
    return pd.DataFrame(out)


def recommend_actions(reasons: pd.DataFrame, meta: pd.DataFrame, max_actions: int = 3) -> list[tuple[str, str]]:
    """Map the strongest risk-raising drivers to concrete retention plays."""
    plays: list[tuple[str, str]] = []
    seen = set()
    for _, r in reasons[reasons["impact"] > 0].iterrows():
        src = meta.loc[meta["feature"] == r["feature"], "source"]
        key = (src.iloc[0] if len(src) else r["feature"]).lower()
        for needles, text in _ACTIONS:
            if any(n in key for n in needles):
                if text not in seen:
                    seen.add(text)
                    plays.append((r["label"], text))
                break
        if len(plays) >= max_actions:
            break
    if not plays:
        plays.append(("Overall profile", "Low risk - keep nurturing; no intervention needed right now"))
    return plays


def risk_band(p: float) -> tuple[str, str]:
    if p >= 0.60:
        return "Critical", "#fb7185"
    if p >= 0.35:
        return "High", "#fbbf24"
    if p >= 0.15:
        return "Medium", "#22d3ee"
    return "Low", "#34d399"


def roi_curve(proba: np.ndarray, value: np.ndarray, offer_cost: float, success_rate: float,
              points: int = 120) -> pd.DataFrame:
    """Expected net value of contacting the top-k riskiest customers, for k = 0..N."""
    order = np.argsort(-proba)
    p, v = proba[order], value[order]
    saved = np.cumsum(p * success_rate * v)
    cost = np.arange(1, len(p) + 1) * offer_cost
    idx = np.unique(np.linspace(0, len(p) - 1, points).astype(int))
    df = pd.DataFrame({"customers": idx + 1, "pct_targeted": (idx + 1) / len(p) * 100,
                       "saved_value": saved[idx], "cost": cost[idx], "net_value": saved[idx] - cost[idx],
                       "risk_cutoff": p[idx]})
    zero = pd.DataFrame([{"customers": 0, "pct_targeted": 0.0, "saved_value": 0.0, "cost": 0.0,
                          "net_value": 0.0, "risk_cutoff": 1.0}])
    return pd.concat([zero, df], ignore_index=True)
