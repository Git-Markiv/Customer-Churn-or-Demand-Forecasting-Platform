"""Synthetic-but-realistic SaaS subscription data, stored as 5 relational tables.

Why synthetic?  The demo has to ship with the project and run offline.  The
generator encodes *causal* churn drivers (contract type, usage decline,
support friction, payment failures, tenure, price sensitivity ...) so the
models genuinely have signal to learn and SHAP has something meaningful to
explain.  Real-world mess (duplicates, casing, missing values, outliers,
invalid values) is injected on purpose so the cleaning stage has real work.

Tables
------
customers        one row per customer (+ ~1% duplicated rows)
subscriptions    plan, contract, price, payment method, churn status / date
monthly_usage    up to 6 monthly usage snapshots before the observation end
support_tickets  tickets raised before the observation end, with CSAT
payments         up to 6 invoices before the observation end
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

from .config import DEMO_DB_PATH, RANDOM_STATE, SNAPSHOT_DATE, SQL_DIR

COUNTRIES = ["United States", "India", "United Kingdom", "Germany", "Brazil", "Canada", "Australia"]
COUNTRY_P = [0.34, 0.18, 0.12, 0.10, 0.08, 0.10, 0.08]
CHANNELS = ["Organic", "Paid Ads", "Referral", "Partner", "Outbound"]
CHANNEL_P = [0.32, 0.26, 0.18, 0.12, 0.12]
CHANNEL_EFFECT = {"Organic": 0.0, "Paid Ads": 0.25, "Referral": -0.30, "Partner": -0.15, "Outbound": 0.15}
SIZES = ["1-10", "11-50", "51-200", "200+"]
PLANS = ["Starter", "Growth", "Business", "Enterprise"]
CONTRACTS = ["Monthly", "Annual", "Two-Year"]
PAY_METHODS = ["Credit Card", "PayPal", "Bank Transfer", "Invoice"]
TICKET_CATEGORIES = ["Technical", "Billing", "Account", "Feature Request", "Performance"]
PRIORITIES = ["Low", "Medium", "High", "Urgent"]


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def _choice_by_rows(rng: np.random.Generator, probs: np.ndarray) -> np.ndarray:
    """Vectorised categorical sampling where every row has its own probability vector."""
    cum = probs.cumsum(axis=1)
    u = rng.random((len(probs), 1))
    return np.minimum((u > cum).sum(axis=1), probs.shape[1] - 1)


def generate_demo_tables(n_customers: int = 10000, seed: int = RANDOM_STATE,
                         target_churn_rate: float = 0.235) -> dict[str, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    n = n_customers
    snap = np.datetime64(SNAPSHOT_DATE, "D")

    # ------------------------------------------------------------------ customers
    customer_id = np.array([f"CUS-{100000 + i}" for i in range(n)])
    tenure_days = np.clip((rng.beta(1.25, 2.4, n) * 365 * 5).astype(int) + 35, 35, 2000)
    signup = snap - tenure_days.astype("timedelta64[D]")
    age = np.clip(rng.normal(39, 11, n), 20, 74).round()
    gender = rng.choice(["Female", "Male", "Non-binary"], n, p=[0.47, 0.49, 0.04])
    country = rng.choice(COUNTRIES, n, p=COUNTRY_P)
    channel = rng.choice(CHANNELS, n, p=CHANNEL_P)
    size_idx = rng.choice(4, n, p=[0.38, 0.34, 0.20, 0.08])
    company_size = np.array(SIZES)[size_idx]

    # ------------------------------------------------------------------ subscription
    plan_p = np.array([[.62, .30, .07, .01], [.30, .45, .20, .05], [.10, .30, .45, .15], [.03, .15, .42, .40]])
    plan_idx = _choice_by_rows(rng, plan_p[size_idx])
    seat_lo, seat_hi = np.array([1, 3, 10, 40]), np.array([4, 16, 61, 301])
    seats = rng.integers(seat_lo[plan_idx], seat_hi[plan_idx])
    contract_p = np.array([[.72, .25, .03], [.55, .37, .08], [.38, .46, .16], [.18, .50, .32]])
    contract_idx = _choice_by_rows(rng, contract_p[plan_idx])
    add_ons = np.clip(rng.poisson(0.9, n), 0, 5)
    per_seat = np.array([12.0, 18.0, 25.0, 30.0])[plan_idx]
    discount = np.array([1.0, 0.90, 0.82])[contract_idx]
    monthly_price = np.round((seats * per_seat * discount + add_ons * 15) * rng.normal(1, 0.04, n), 2)
    price_per_seat = monthly_price / seats
    price_sens = (price_per_seat - price_per_seat.mean()) / price_per_seat.std()

    pay_method = rng.choice(PAY_METHODS, n, p=[0.46, 0.18, 0.22, 0.14])
    autopay_p = pd.Series(pay_method).map({"Credit Card": .78, "PayPal": .70, "Bank Transfer": .45, "Invoice": 0.0})
    autopay = (rng.random(n) < autopay_p.to_numpy()).astype(int)

    # ------------------------------------------------------------------ latent drivers
    sat = rng.normal(0, 1, n)                                   # satisfaction
    trend = 0.45 * sat + rng.normal(0, 0.9, n)                  # usage momentum (>0 = growing)
    pay_risk = np.clip(rng.beta(1.0, 11.0, n) + 0.06 * (autopay == 0) + 0.04 * (pay_method == "Invoice"), 0, 0.6)

    tenure_m = tenure_days / 30.4
    trend_c = np.clip(trend, -2.5, 2.5)
    # Non-linear + interaction effects (what lets boosted trees beat a linear model):
    #   * usage momentum saturates (tanh) instead of growing forever
    #   * month-to-month customers with falling usage are a flight risk (interaction)
    #   * very unhappy customers churn disproportionately (threshold)
    #   * payment failures only hurt once they become frequent (threshold)
    #   * price sensitivity matters for small plans only (interaction)
    logit = (
        np.array([0.85, -0.30, -0.95])[contract_idx]
        + np.array([0.30, 0.0, -0.10, -0.35])[plan_idx]
        + pd.Series(channel).map(CHANNEL_EFFECT).to_numpy()
        - 0.95 * np.tanh(1.1 * trend_c)
        + 1.0 * (contract_idx == 0) * np.maximum(-trend_c - 0.3, 0)
        - 0.30 * sat - 0.85 * np.maximum(-sat - 0.9, 0)
        + 11.0 * np.maximum(pay_risk - 0.12, 0) + 1.0 * (pay_risk - 0.08)
        + 0.95 * np.exp(-tenure_m / 4.0) - 0.20 * np.log1p(tenure_m)
        - 0.40 * autopay + 0.35 * price_sens * (plan_idx <= 1) - 0.10 * add_ons
        # renewal cliff: non-monotonic churn spike when an annual / two-year term comes up for renewal
        + 1.5 * (contract_idx == 1) * np.exp(-((tenure_m % 12 - 11.0) ** 2) / 2.0)
        + 1.5 * (contract_idx == 2) * np.exp(-((tenure_m % 24 - 23.0) ** 2) / 4.0)
        + rng.normal(0, 0.35, n)                                  # unobserved factors
    )
    lo, hi = -8.0, 6.0
    for _ in range(50):                                          # calibrate intercept to target rate
        mid = (lo + hi) / 2
        if _sigmoid(logit + mid).mean() < target_churn_rate:
            lo = mid
        else:
            hi = mid
    churn = rng.random(n) < _sigmoid(logit + (lo + hi) / 2)

    churn_date = snap - rng.integers(1, 270, n).astype("timedelta64[D]")
    too_early = churn & (churn_date < signup + np.timedelta64(45, "D"))
    signup = np.where(too_early, churn_date - (45 + rng.integers(0, 40, n)).astype("timedelta64[D]"), signup)
    obs_end = np.where(churn, churn_date, snap)
    obs_days = (obs_end - signup).astype(int)

    # ------------------------------------------------------------------ monthly usage
    months_avail = np.clip(obs_days // 30, 1, 6)
    base_logins = rng.lognormal(3.0, 0.5, n) * (0.5 + 0.25 * np.log1p(seats))
    base_api = np.array([20.0, 400.0, 2500.0, 12000.0])[plan_idx] * rng.lognormal(0, 0.5, n)
    usage_parts = []
    for k in range(1, 7):
        keep = k >= 7 - months_avail
        mult = np.exp(0.11 * trend * (k - 3.5)) * rng.lognormal(0, 0.15, n)
        if k >= 5:                                              # pre-churn disengagement
            mult = np.where(churn, mult * rng.uniform(0.60, 0.97, n), mult)
        logins = rng.poisson(base_logins * mult)
        minutes = np.round(logins * rng.lognormal(3.2, 0.35, n), 1)
        features = np.clip(np.round(rng.poisson(2.5 + 1.8 * plan_idx) * mult ** 0.5), 0, 25)
        api = rng.poisson(base_api * mult)
        usage_parts.append(pd.DataFrame({
            "customer_id": customer_id[keep], "period_idx": k,
            "month_start": (obs_end - np.timedelta64((6 - k + 1) * 30, "D"))[keep].astype(str),
            "logins": logins[keep].astype(float), "active_minutes": minutes[keep],
            "features_used": features[keep], "api_calls": api[keep].astype(float),
        }))
    usage = pd.concat(usage_parts, ignore_index=True)

    # ------------------------------------------------------------------ support tickets
    months_obs = np.clip(obs_days / 30.4, 1, 12)
    ticket_rate = 0.22 * np.exp(-0.35 * sat + 0.12 * np.log1p(seats)) * (1 + 0.5 * (plan_idx == 3))
    n_tickets = rng.poisson(ticket_rate * months_obs)
    rep = np.repeat(np.arange(n), n_tickets)
    m = len(rep)
    prio_score = rng.normal(0, 1, m) - 0.4 * sat[rep]
    prio_idx = np.digitize(prio_score, [-0.5, 0.4, 1.1])
    res_hours = np.round(np.clip(np.exp(np.log(8) + 0.35 * prio_idx - 0.15 * sat[rep] + rng.normal(0, 0.6, m)), 0.2, 400), 1)
    csat = np.clip(np.round(3.5 + 0.9 * sat[rep] - 0.25 * prio_idx + rng.normal(0, 0.8, m)), 1, 5)
    csat = np.where(rng.random(m) < 0.22, np.nan, csat)
    created = obs_end[rep] - (rng.random(m) * np.minimum(obs_days[rep], 365)).astype(int).astype("timedelta64[D]")
    tickets = pd.DataFrame({
        "ticket_id": np.arange(1, m + 1), "customer_id": customer_id[rep],
        "created_date": created.astype(str),
        "category": rng.choice(TICKET_CATEGORIES, m, p=[.34, .22, .14, .12, .18]),
        "priority": np.array(PRIORITIES)[prio_idx], "resolution_hours": res_hours, "csat": csat,
    })

    # ------------------------------------------------------------------ payments
    n_pay = np.clip(obs_days // 30, 1, 6)
    rep = np.repeat(np.arange(n), n_pay)
    j = np.concatenate([np.arange(1, k + 1) for k in n_pay])
    m = len(rep)
    u = rng.random(m)
    p = pay_risk[rep]
    status = np.where(u < p * 0.45, "failed", np.where(u < p, "late", "paid"))
    pay_date = obs_end[rep] - ((j - 1) * 30 + rng.integers(0, 4, m)).astype("timedelta64[D]")
    payments = pd.DataFrame({
        "payment_id": np.arange(1, m + 1), "customer_id": customer_id[rep],
        "payment_date": pay_date.astype(str),
        "amount": np.round(monthly_price[rep] * rng.normal(1, 0.01, m), 2), "status": status,
    })

    # ------------------------------------------------------------------ assemble core tables
    customers = pd.DataFrame({
        "customer_id": customer_id, "signup_date": signup.astype(str), "age": age, "gender": gender,
        "country": country, "company_size": company_size, "acquisition_channel": channel,
    })
    subscriptions = pd.DataFrame({
        "subscription_id": np.arange(1, n + 1), "customer_id": customer_id,
        "plan": np.array(PLANS)[plan_idx], "contract_type": np.array(CONTRACTS)[contract_idx],
        "seats": seats, "monthly_price": monthly_price, "add_ons": add_ons, "payment_method": pay_method,
        "autopay": autopay, "status": np.where(churn, "churned", "active"),
        "start_date": signup.astype(str), "end_date": np.where(churn, churn_date.astype(str), None),
    })

    # ------------------------------------------------------------------ inject real-world mess
    c = customers
    idx = rng.random(n)
    c.loc[idx < 0.06, "country"] = c.loc[idx < 0.06, "country"].str.lower()
    c.loc[(idx >= 0.06) & (idx < 0.10), "country"] = c.loc[(idx >= 0.06) & (idx < 0.10), "country"] + "  "
    c.loc[(idx >= 0.10) & (idx < 0.13) & (c["country"] == "United States"), "country"] = "USA"
    c.loc[rng.random(n) < 0.02, "gender"] = None
    c.loc[rng.random(n) < 0.035, "age"] = np.nan
    bad_age = rng.random(n) < 0.003
    c.loc[bad_age, "age"] = rng.choice([0, 150, 999], bad_age.sum())
    customers = pd.concat([c, c.sample(frac=0.012, random_state=seed)], ignore_index=True) \
        .sample(frac=1, random_state=seed).reset_index(drop=True)

    s = subscriptions
    jitter = rng.random(n)
    s.loc[jitter < 0.03, "plan"] = s.loc[jitter < 0.03, "plan"].str.lower()
    s.loc[(jitter >= 0.03) & (jitter < 0.05), "plan"] = s.loc[(jitter >= 0.03) & (jitter < 0.05), "plan"] + " "
    s.loc[rng.random(n) < 0.002, "monthly_price"] *= -1

    u_ = usage
    spike = rng.random(len(u_))
    u_.loc[spike < 0.0015, "active_minutes"] *= 40
    u_.loc[(spike >= 0.0015) & (spike < 0.0025), "logins"] = -1
    u_.loc[(spike >= 0.0025) & (spike < 0.0065), "logins"] = np.nan

    return {"customers": customers, "subscriptions": s, "monthly_usage": u_,
            "support_tickets": tickets, "payments": payments}


def build_demo_database(db_path: Path | str = DEMO_DB_PATH, n_customers: int = 10000,
                        seed: int = RANDOM_STATE, force: bool = False) -> Path:
    """Create the SQLite demo database from sql/schema.sql (idempotent)."""
    db_path = Path(db_path)
    if db_path.exists() and not force:
        return db_path
    db_path.parent.mkdir(parents=True, exist_ok=True)
    if db_path.exists():
        db_path.unlink()
    tables = generate_demo_tables(n_customers, seed)
    with sqlite3.connect(db_path) as conn:
        conn.executescript((SQL_DIR / "schema.sql").read_text())
        for name, df in tables.items():
            df.to_sql(name, conn, if_exists="append", index=False)
        conn.commit()
    return db_path
