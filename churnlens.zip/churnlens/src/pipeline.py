"""End-to-end orchestration: SQL -> clean -> features -> CV compare -> tune -> evaluate -> SHAP -> score.

Run from the command line to pre-build the demo cache:
    python -m src.pipeline --demo
or analyse your own file:
    python -m src.pipeline --csv my.csv --target Churn --positive Yes
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from . import modeling as M
from .cleaning import CleaningReport, CleaningStep, clean_dataframe, to_snake
from .config import ARTIFACT_DIR, DEMO_DB_PATH, ID_COL, RANDOM_STATE, TARGET
from .db import extract_demo_features, run_user_sql
from .explain import ShapBundle, explain_rows
from .features import feature_metadata
from .loader import prepare_custom_frame, read_table

CACHE_DIR = ARTIFACT_DIR / "cache"
Progress = Callable[[float, str], None]

PRESETS = {
    "Quick":    dict(n_iter=8,  tune_top_k=1, folds=3, tune_folds=3),
    "Balanced": dict(n_iter=16, tune_top_k=2, folds=5, tune_folds=3),
    "Thorough": dict(n_iter=32, tune_top_k=3, folds=5, tune_folds=4),
}


@dataclass
class RunConfig:
    source: str = "demo"                       # "demo" | "custom"
    target_col: str | None = None
    positive_value: Any = None
    id_col: str | None = None
    revenue_col: str | None = None
    default_monthly_value: float = 100.0       # used for ROI when there is no revenue column
    sql_query: str | None = None
    models: tuple = ()
    metric: str = "pr_auc"                     # selection metric: pr_auc | roc_auc | f1
    folds: int = 5
    tune_folds: int = 3
    tune_top_k: int = 2
    n_iter: int = 16
    test_size: float = 0.2
    seed: int = RANDOM_STATE

    def key(self, data_signature: str) -> str:
        from .modeling import available_models
        d = asdict(self)
        d["models"] = sorted(self.models or available_models())      # () means "all models"
        blob = json.dumps({**d, "sig": data_signature, "v": 3}, sort_keys=True, default=str)
        return hashlib.md5(blob.encode()).hexdigest()[:16]


@dataclass
class PipelineResult:
    run_id: str
    config: RunConfig
    source_label: str
    sql_text: str
    extracted: pd.DataFrame
    clean: pd.DataFrame
    report: CleaningReport
    X: pd.DataFrame
    y: pd.Series
    ids: pd.Series
    annual_value: np.ndarray
    value_label: str
    train_idx: np.ndarray
    test_idx: np.ndarray
    leaderboard: pd.DataFrame
    tuning: dict
    best_name: str
    best_stage: str
    best_params: dict
    final: M.FinalFit
    shap: ShapBundle
    meta: pd.DataFrame
    scores: pd.DataFrame
    full_model: Any
    notes: list = field(default_factory=list)
    timings: dict = field(default_factory=dict)


# ------------------------------------------------------------------------------------ helpers
def data_signature(df: pd.DataFrame | None) -> str:
    if df is None:
        p = Path(DEMO_DB_PATH)
        return f"demo-{p.stat().st_size if p.exists() else 0}"
    h = pd.util.hash_pandas_object(df, index=True).sum()
    return f"{df.shape}-{h}"


def _subsample(X: pd.DataFrame, y: pd.Series, max_rows: int, seed: int):
    if len(X) <= max_rows:
        return X, y
    Xs, _, ys, _ = train_test_split(X, y, train_size=max_rows, stratify=y, random_state=seed)
    return Xs, ys


def _validate(clean: pd.DataFrame) -> None:
    n, pos = len(clean), int(clean[TARGET].sum())
    if n < 150:
        raise ValueError(f"Only {n} usable rows after cleaning - at least 150 are needed to train and validate models.")
    if pos < 30 or (n - pos) < 30:
        raise ValueError(f"Need at least 30 churned AND 30 retained customers (found {pos} churned / {n - pos} retained). "
                         "Check that the 'churn' value you selected is correct.")
    if clean.shape[1] < 4:
        raise ValueError("Too few feature columns after cleaning - add more columns to your dataset or SQL query.")


# ------------------------------------------------------------------------------------ main run
def run_pipeline(cfg: RunConfig, raw: pd.DataFrame | None = None, progress: Progress | None = None) -> PipelineResult:
    def tick(frac: float, msg: str) -> None:
        if progress:
            progress(min(frac, 1.0), msg)

    T: dict[str, float] = {}
    notes: list[str] = []
    t0 = time.time()

    # 1 ── SQL extraction ----------------------------------------------------------------------
    tick(0.02, "Running SQL extraction")
    if cfg.source == "demo":
        extracted, sql_text = extract_demo_features()
        source_label = "Demo SaaS warehouse (5 tables, SQLite)"
        value_col = "monthly_price"
        with sqlite3.connect(DEMO_DB_PATH) as conn:
            raw_dups = conn.execute("SELECT COUNT(*) - COUNT(DISTINCT customer_id) FROM customers").fetchone()[0]
    else:
        if raw is None:
            raise ValueError("No dataset supplied.")
        query = cfg.sql_query or "SELECT * FROM data"
        sql_text = query
        extracted = run_user_sql(raw, query)
        source_label = "Uploaded dataset (SQL over table `data`)"
        value_col = cfg.revenue_col
        raw_dups = 0
        if cfg.target_col not in extracted.columns:
            raise ValueError(f"Your SQL result does not contain the target column '{cfg.target_col}'.")
        extracted = prepare_custom_frame(extracted, cfg.target_col, cfg.positive_value, cfg.id_col, cfg.revenue_col)
    T["sql"] = time.time() - t0

    # 2 ── cleaning ------------------------------------------------------------------------------
    tick(0.07, "Cleaning data")
    t1 = time.time()
    clean, report = clean_dataframe(extracted)
    if raw_dups:
        report.steps.insert(0, CleaningStep("Remove duplicate customers (in SQL)",
                                            "ROW_NUMBER() window keeps one row per customer_id", int(raw_dups), "fix"))
    _validate(clean)
    T["clean"] = time.time() - t1

    # revenue → annual value per customer (used for ROI and revenue-at-risk)
    value_name = to_snake(value_col) if value_col else None
    if value_name and value_name in clean.columns and pd.api.types.is_numeric_dtype(clean[value_name]):
        monthly = clean[value_name].fillna(clean[value_name].median()).clip(lower=0).to_numpy(float)
        value_label = f"{value_name} × 12"
    else:
        monthly = np.full(len(clean), float(cfg.default_monthly_value))
        value_label = f"flat {cfg.default_monthly_value:,.0f} / month × 12"
        notes.append("No revenue column found - ROI uses a flat monthly value per customer.")
    annual_value = monthly * 12

    # 3 ── modelling frame & split --------------------------------------------------------------
    tick(0.10, "Engineering features & splitting")
    y = clean[TARGET].astype(int)
    ids = clean[ID_COL].astype(str)
    X = clean.drop(columns=[TARGET, ID_COL])
    rate = y.mean()
    if rate < 0.10 or rate > 0.90:
        notes.append(f"Imbalanced target ({rate:.1%} churn) - ranking metrics (PR-AUC) are emphasised.")
    folds = int(max(2, min(cfg.folds, int(y.sum()) // 10, int((len(y) - y.sum())) // 10)))
    tune_folds = max(2, min(cfg.tune_folds, folds))
    idx = np.arange(len(X))
    tr_idx, te_idx = train_test_split(idx, test_size=cfg.test_size, stratify=y, random_state=cfg.seed)
    X_tr, X_te, y_tr, y_te = X.iloc[tr_idx], X.iloc[te_idx], y.iloc[tr_idx], y.iloc[te_idx]
    X_cv, y_cv = _subsample(X_tr, y_tr, 40000, cfg.seed)
    if len(X_cv) < len(X_tr):
        notes.append(f"Large dataset: model comparison and tuning used a stratified sample of {len(X_cv):,} training rows.")

    # 4 ── baseline comparison with cross-validation ------------------------------------------------
    names = [m for m in (cfg.models or M.available_models()) if m in M.MODEL_SPECS]
    if not names:
        raise ValueError("Select at least one model.")
    t2 = time.time()
    baseline_rows = []
    for i, name in enumerate(names):
        tick(0.12 + 0.30 * i / len(names), f"Cross-validating {name}  ({folds}-fold)")
        baseline_rows.append(M.compare_models(X_cv, y_cv, [name], folds, cfg.seed).iloc[0].to_dict())
    leaderboard_rows = list(baseline_rows)
    T["cv"] = time.time() - t2

    # 5 ── hyper-parameter tuning of the strongest candidates ---------------------------------------
    t3 = time.time()
    ranked = sorted(baseline_rows, key=lambda r: r[cfg.metric], reverse=True)
    to_tune = [r["model"] for r in ranked[:cfg.tune_top_k]]
    tuning: dict[str, M.TuneResult] = {}
    for j, name in enumerate(to_tune):
        tick(0.43 + 0.37 * j / max(len(to_tune), 1), f"Tuning {name}  (randomized search)")
        tr = M.tune_model(name, X_cv, y_cv, cfg.n_iter, tune_folds, cfg.seed, cfg.metric)
        tuning[name] = tr
        leaderboard_rows.append({"model": name, "stage": "Tuned", **tr.summary, "fit_seconds": np.nan,
                                 "wall_seconds": tr.seconds, "params": tr.best_params})
    T["tune"] = time.time() - t3
    leaderboard = pd.DataFrame(leaderboard_rows)
    leaderboard = leaderboard.sort_values(cfg.metric, ascending=False).reset_index(drop=True)
    leaderboard.insert(0, "rank", np.arange(1, len(leaderboard) + 1))
    best = leaderboard.iloc[0]
    best_name, best_stage, best_params = best["model"], best["stage"], dict(best["params"] or {})

    # 6 ── hold-out evaluation --------------------------------------------------------------------------
    tick(0.82, f"Evaluating {best_name} on the hold-out set")
    t4 = time.time()
    final = M.fit_and_evaluate(best_name, best_params, X_tr, y_tr, X_te, y_te, X, folds, cfg.seed)
    T["final"] = time.time() - t4

    # 7 ── SHAP on unseen customers ----------------------------------------------------------------------
    tick(0.88, "Computing SHAP explanations")
    t5 = time.time()
    background = X_tr.sample(min(300, len(X_tr)), random_state=cfg.seed)
    bundle, _ = explain_rows(final.pipeline, X_te, background, ids.iloc[te_idx].to_numpy(), seed=cfg.seed)
    T["shap"] = time.time() - t5

    # 8 ── score every customer out-of-fold + production model ----------------------------------------------
    tick(0.93, "Scoring all customers (out-of-fold)")
    t6 = time.time()
    oof = M.oof_probabilities(best_name, best_params, X, y, folds, cfg.seed)
    scores = pd.DataFrame({ID_COL: ids.to_numpy(), "churn": y.to_numpy(), "proba": oof,
                           "annual_value": annual_value})
    tick(0.97, "Fitting the production model")
    full_model = M.fit_full(best_name, best_params, X, y, cfg.seed)
    meta = feature_metadata(full_model)
    T["score"] = time.time() - t6
    T["total"] = time.time() - t0
    tick(1.0, "Done")

    return PipelineResult(
        run_id="", config=cfg, source_label=source_label, sql_text=sql_text, extracted=extracted, clean=clean,
        report=report, X=X, y=y, ids=ids, annual_value=annual_value, value_label=value_label, train_idx=tr_idx,
        test_idx=te_idx, leaderboard=leaderboard, tuning=tuning, best_name=best_name, best_stage=best_stage,
        best_params=best_params, final=final, shap=bundle, meta=meta, scores=scores, full_model=full_model,
        notes=notes, timings=T)


# ------------------------------------------------------------------------------------ caching
def run_or_load(cfg: RunConfig, raw: pd.DataFrame | None = None, progress: Progress | None = None,
                force: bool = False) -> tuple[PipelineResult, bool]:
    """Return (result, loaded_from_cache). Results are cached on disk by config + data signature."""
    if cfg.source == "demo":
        from .data_gen import build_demo_database
        build_demo_database()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    key = cfg.key(data_signature(raw if cfg.source == "custom" else None))
    path = CACHE_DIR / f"{key}.joblib"
    if path.exists() and not force:
        try:
            res = joblib.load(path)
            if progress:
                progress(1.0, "Loaded from cache")
            return res, True
        except Exception:                                    # stale / incompatible cache -> recompute
            path.unlink(missing_ok=True)
    res = run_pipeline(cfg, raw, progress)
    res.run_id = key
    joblib.dump(res, path, compress=3)
    return res, False



def peek_cache(cfg: RunConfig, raw: pd.DataFrame | None = None) -> PipelineResult | None:
    """Load a previously computed result without running anything (None if absent)."""
    if cfg.source == "demo" and not Path(DEMO_DB_PATH).exists():
        return None
    key = cfg.key(data_signature(raw if cfg.source == "custom" else None))
    path = CACHE_DIR / f"{key}.joblib"
    if path.exists():
        try:
            return joblib.load(path)
        except Exception:
            path.unlink(missing_ok=True)
    return None


# ------------------------------------------------------------------------------------ CLI
def _cli() -> None:
    ap = argparse.ArgumentParser(description="ChurnLens pipeline")
    ap.add_argument("--demo", action="store_true", help="run on the built-in demo warehouse")
    ap.add_argument("--csv", help="path to your own dataset (csv/xlsx)")
    ap.add_argument("--target", help="name of the churn column")
    ap.add_argument("--positive", help="value in the target column that means 'churned'")
    ap.add_argument("--id", dest="id_col", help="customer id column (optional)")
    ap.add_argument("--preset", default="Balanced", choices=list(PRESETS))
    ap.add_argument("--force", action="store_true", help="ignore the cache")
    a = ap.parse_args()
    if not a.demo and not a.csv:
        ap.error("pass --demo or --csv")
    preset = PRESETS[a.preset]
    raw = None
    if a.csv:
        if not a.target or a.positive is None:
            ap.error("--csv needs --target and --positive")
        raw = read_table(a.csv)
        cfg = RunConfig(source="custom", target_col=a.target, positive_value=a.positive, id_col=a.id_col, **preset)
    else:
        cfg = RunConfig(source="demo", **preset)
    last = {"msg": ""}

    def show(frac: float, msg: str) -> None:
        if msg != last["msg"]:
            print(f"[{frac * 100:5.1f}%] {msg}", flush=True)
            last["msg"] = msg

    res, cached = run_or_load(cfg, raw, show, force=a.force)
    cols = ["rank", "model", "stage", "roc_auc", "pr_auc", "f1", "recall"]
    print("\nLeaderboard (cross-validated):")
    print(res.leaderboard[cols].round(4).to_string(index=False))
    print(f"\nBest: {res.best_name} ({res.best_stage}) | hold-out ROC-AUC {res.final.holdout['roc_auc']:.4f} "
          f"PR-AUC {res.final.holdout['pr_auc']:.4f} | threshold {res.final.threshold:.3f}")
    print(f"Cache: {'hit' if cached else 'built'}  ({res.run_id})  total {res.timings.get('total', 0):.0f}s")


if __name__ == "__main__":
    # Re-import under its real name so cached results pickle as `src.pipeline.*` (loadable by the app),
    # not as `__main__.*`.
    import src.pipeline as _real

    _real._cli()
