"""Plotly figures with one consistent dark theme (thin marks, recessive grid, legends, hover)."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.calibration import calibration_curve
from sklearn.metrics import precision_recall_curve, roc_curve

from .cleaning import is_text

C = {"churn": "#fb7185", "stay": "#22d3ee", "violet": "#a78bfa", "amber": "#fbbf24", "green": "#34d399",
     "text": "#e8ebf7", "muted": "#8f97b8", "grid": "rgba(255,255,255,0.06)", "line": "rgba(255,255,255,0.14)"}
SEQ = [[0, "#1b2140"], [0.5, "#6d4af0"], [1, "#22d3ee"]]
DIV = [[0, "#22d3ee"], [0.5, "#1c2038"], [1, "#fb7185"]]
CAT = ["#22d3ee", "#fb7185", "#a78bfa", "#fbbf24", "#34d399"]


def base(fig: go.Figure, height: int = 380, title: str | None = None, legend: bool = True) -> go.Figure:
    fig.update_layout(
        height=height, title=dict(text=title, x=0.01, font=dict(size=15, color=C["text"])) if title else None,
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, system-ui, sans-serif", color=C["muted"], size=12),
        margin=dict(l=8, r=8, t=46 if title else 16, b=8), showlegend=legend,
        legend=dict(orientation="h", y=1.02 if not title else 1.1, x=1, xanchor="right", bgcolor="rgba(0,0,0,0)",
                    font=dict(color=C["text"])),
        hoverlabel=dict(bgcolor="#151a31", bordercolor="rgba(255,255,255,.2)", font=dict(color="#e8ebf7", family="Inter")),
        transition=dict(duration=500, easing="cubic-in-out"), hovermode="closest")
    fig.update_xaxes(gridcolor=C["grid"], zeroline=False, linecolor=C["line"], tickfont=dict(color=C["muted"]),
                     title_font=dict(color=C["muted"]))
    fig.update_yaxes(gridcolor=C["grid"], zeroline=False, linecolor="rgba(0,0,0,0)", tickfont=dict(color=C["muted"]),
                     title_font=dict(color=C["muted"]))
    return fig


def hex_rgba(h: str, a: float) -> str:
    h = h.lstrip("#")
    return f"rgba({int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)},{a})"


# ------------------------------------------------------------------------------ EDA
def churn_donut(rate: float) -> go.Figure:
    fig = go.Figure(go.Pie(values=[rate, 1 - rate], labels=["Churned", "Retained"], hole=0.74, sort=False,
                           marker=dict(colors=[C["churn"], C["stay"]], line=dict(color="#0f1324", width=3)),
                           textinfo="none", hovertemplate="%{label}: %{percent}<extra></extra>"))
    fig.add_annotation(text=f"<b style='font-size:28px;color:#e8ebf7'>{rate:.1%}</b><br><span style='color:#8f97b8'>churn rate</span>",
                       showarrow=False)
    fig = base(fig, 300, legend=True)
    fig.update_layout(legend=dict(orientation="h", x=0.5, xanchor="center", y=-0.04, yanchor="top"), margin=dict(l=8, r=8, t=8, b=36))
    return fig


def churn_by_category(df: pd.DataFrame, col: str, target: str = "churn", top: int = 12) -> go.Figure:
    g = df.groupby(col, dropna=False)[target].agg(["mean", "size"]).reset_index()
    g[col] = g[col].astype(str).replace({"nan": "Missing"})
    g = g[g["size"] >= max(5, int(0.003 * len(df)))].sort_values("mean", ascending=False).head(top)
    g = g.sort_values("mean")
    overall = df[target].mean()
    fig = go.Figure(go.Bar(x=g["mean"], y=g[col], orientation="h", customdata=g["size"],
                           marker=dict(color=g["mean"], colorscale=SEQ, cmin=0, cmax=max(g["mean"].max(), overall) * 1.05),
                           hovertemplate="<b>%{y}</b><br>Churn rate %{x:.1%}<br>%{customdata:,} customers<extra></extra>",
                           text=[f"{v:.0%}" for v in g["mean"]], textposition="outside", textfont=dict(color=C["text"])))
    fig.add_vline(x=overall, line=dict(color=C["amber"], width=1.5, dash="dot"),
                  annotation_text=f"avg {overall:.0%}", annotation_font_color=C["amber"], annotation_position="top")
    fig.update_xaxes(tickformat=".0%", range=[0, max(g["mean"].max() * 1.2, overall * 1.3)])
    fig.update_yaxes(automargin=True)
    return base(fig, max(260, 46 * len(g) + 70), legend=False)


def numeric_distribution(df: pd.DataFrame, col: str, target: str = "churn") -> go.Figure:
    s = df[[col, target]].dropna()
    lo, hi = s[col].quantile([0.005, 0.995])
    s = s[(s[col] >= lo) & (s[col] <= hi)]
    fig = go.Figure()
    for val, name, color in ((0, "Retained", C["stay"]), (1, "Churned", C["churn"])):
        fig.add_trace(go.Histogram(x=s.loc[s[target] == val, col], name=name, histnorm="probability density", opacity=0.62,
                                   nbinsx=40, marker=dict(color=color, line=dict(color="#0f1324", width=1)),
                                   hovertemplate="%{x}<br>density %{y:.4f}<extra>" + name + "</extra>"))
    fig.update_layout(barmode="overlay", bargap=0.04)
    fig.update_yaxes(title="density", showticklabels=False)
    return base(fig, 330)


def binned_churn(df: pd.DataFrame, col: str, target: str = "churn", bins: int = 10) -> go.Figure:
    s = df[[col, target]].dropna()
    s["bin"] = pd.qcut(s[col], q=min(bins, s[col].nunique()), duplicates="drop")
    g = s.groupby("bin", observed=True).agg(rate=(target, "mean"), n=(target, "size"), mid=(col, "median")).reset_index()
    fig = go.Figure(go.Scatter(x=g["mid"], y=g["rate"], mode="lines+markers", line=dict(color=C["violet"], width=2.5, shape="spline"),
                               marker=dict(size=9, color=C["violet"], line=dict(color="#0f1324", width=2)), customdata=g["n"],
                               fill="tozeroy", fillcolor=hex_rgba("#8b5cf6", 0.10),
                               hovertemplate=f"{col} ≈ %{{x:,.2f}}<br>Churn %{{y:.1%}}<br>%{{customdata:,}} customers<extra></extra>"))
    fig.add_hline(y=df[target].mean(), line=dict(color=C["amber"], dash="dot", width=1.2))
    fig.update_yaxes(tickformat=".0%", rangemode="tozero")
    return base(fig, 330, legend=False)


def correlation_heatmap(df: pd.DataFrame, target: str = "churn", max_cols: int = 18) -> go.Figure:
    num = df.select_dtypes("number")
    num = num.loc[:, num.nunique() > 1]
    corr_t = num.corr()[target].drop(target).abs().sort_values(ascending=False)
    cols = [target] + corr_t.head(max_cols - 1).index.tolist()
    m = num[cols].corr()
    fig = go.Figure(go.Heatmap(z=m.values, x=cols, y=cols, zmin=-1, zmax=1, colorscale=DIV, xgap=2, ygap=2,
                               hovertemplate="%{y} × %{x}<br>r = %{z:.2f}<extra></extra>",
                               colorbar=dict(thickness=10, outlinewidth=0, tickfont=dict(color=C["muted"]))))
    fig.update_yaxes(autorange="reversed", automargin=True)
    fig.update_xaxes(tickangle=-45, automargin=True)
    return base(fig, 520, legend=False)


def missing_bar(miss: pd.Series, n_rows: int) -> go.Figure:
    miss = miss.head(15).sort_values()
    pct = miss / n_rows
    fig = go.Figure(go.Bar(x=pct, y=miss.index, orientation="h", marker=dict(color=C["amber"]), customdata=miss,
                           hovertemplate="<b>%{y}</b><br>%{x:.1%} missing (%{customdata:,} rows)<extra></extra>"))
    fig.update_xaxes(tickformat=".0%")
    return base(fig, max(220, 32 * len(miss) + 60), legend=False)


# ------------------------------------------------------------------------------ models
METRIC_NAMES = {"roc_auc": "ROC-AUC", "pr_auc": "PR-AUC", "f1": "F1", "recall": "Recall", "precision": "Precision"}


def leaderboard_chart(lb: pd.DataFrame, metric: str) -> go.Figure:
    d = lb.copy()
    d["label"] = d["model"] + np.where(d["stage"] == "Tuned", " (tuned)", "")
    d = d.sort_values(metric)
    colors = [C["violet"] if st == "Tuned" else C["stay"] for st in d["stage"]]
    fig = go.Figure(go.Bar(x=d[metric], y=d["label"], orientation="h", marker=dict(color=colors),
                           error_x=dict(type="data", array=d[f"{metric}_std"], color="rgba(255,255,255,.45)", thickness=1.4, width=4),
                           name="Cross-validated", showlegend=False,
                           text=[f"{v:.3f}" for v in d[metric]], textposition="inside", insidetextanchor="start",
                           textfont=dict(color="#06101a", size=12),
                           hovertemplate="<b>%{y}</b><br>" + METRIC_NAMES.get(metric, metric) + " %{x:.4f}<extra></extra>"))
    lo = max(0.0, float(d[metric].min()) - 0.06)
    fig.update_xaxes(range=[lo, min(1.0, float(d[metric].max()) + 0.04)], title=f"{METRIC_NAMES.get(metric, metric)} (CV mean ± std)")
    fig.update_yaxes(automargin=True)
    for name, color in (("Baseline", C["stay"]), ("Tuned", C["violet"])):
        fig.add_trace(go.Bar(x=[None], y=[None], name=name, marker=dict(color=color), showlegend=True))
    fig = base(fig, max(300, 44 * len(d) + 110))
    fig.update_layout(margin=dict(l=8, r=8, t=44, b=8))
    return fig


def metric_radar(lb: pd.DataFrame, top: int = 4) -> go.Figure:
    metrics = ["roc_auc", "pr_auc", "f1", "recall", "precision"]
    d = lb.head(top)
    fig = go.Figure()
    for i, (_, r) in enumerate(d.iterrows()):
        vals = [r[m] for m in metrics]
        fig.add_trace(go.Scatterpolar(r=vals + vals[:1], theta=[METRIC_NAMES[m] for m in metrics] + [METRIC_NAMES[metrics[0]]],
                                      name=f"{r['model']} ({r['stage'][0]})", line=dict(color=CAT[i], width=2),
                                      fill="toself", fillcolor=hex_rgba(CAT[i], 0.07)))
    fig.update_layout(polar=dict(bgcolor="rgba(0,0,0,0)", radialaxis=dict(range=[0.3, 1], gridcolor=C["grid"], tickfont=dict(size=10),
                                                                          linecolor=C["grid"], tickvals=[.4, .6, .8]),
                                 angularaxis=dict(gridcolor=C["grid"], tickfont=dict(color=C["text"]))))
    fig = base(fig, 400)
    fig.update_layout(legend=dict(orientation="h", x=0.5, xanchor="center", y=-0.08, yanchor="top"), margin=dict(l=70, r=90, t=24, b=48))
    return fig


def tuning_trials(trials: pd.DataFrame, baseline: float, metric: str, model: str) -> go.Figure:
    t = trials.sort_values("trial")
    best_so_far = t["score"].cummax()
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=t["trial"], y=t["score"], mode="markers", name="Trial",
                             marker=dict(size=10, color=C["violet"], line=dict(color="#0f1324", width=2)),
                             hovertemplate="Trial %{x}<br>" + METRIC_NAMES.get(metric, metric) + " %{y:.4f}<extra></extra>"))
    fig.add_trace(go.Scatter(x=t["trial"], y=best_so_far, mode="lines", name="Best so far", line=dict(color=C["green"], width=2.5, shape="hv")))
    fig.add_hline(y=baseline, line=dict(color=C["amber"], dash="dot", width=1.3), annotation_text="untuned baseline",
                  annotation_font_color=C["amber"], annotation_position="bottom right")
    fig.update_xaxes(title="randomized-search trial", dtick=max(1, len(t) // 8))
    fig.update_yaxes(title=f"CV {METRIC_NAMES.get(metric, metric)}")
    return base(fig, 330, title=model)


def roc_pr_curves(y: np.ndarray, p: np.ndarray) -> go.Figure:
    fpr, tpr, _ = roc_curve(y, p)
    prec, rec, _ = precision_recall_curve(y, p)
    fig = make_subplots(rows=1, cols=2, subplot_titles=("ROC curve", "Precision-Recall curve"), horizontal_spacing=0.1)
    fig.add_trace(go.Scatter(x=fpr, y=tpr, mode="lines", name="Model", line=dict(color=C["stay"], width=2.5), fill="tozeroy",
                             fillcolor=hex_rgba("#22d3ee", 0.10), hovertemplate="FPR %{x:.2f}<br>TPR %{y:.2f}<extra></extra>"), 1, 1)
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Chance", line=dict(color=C["muted"], dash="dot", width=1)), 1, 1)
    fig.add_trace(go.Scatter(x=rec, y=prec, mode="lines", name="Model (PR)", showlegend=False, line=dict(color=C["violet"], width=2.5),
                             fill="tozeroy", fillcolor=hex_rgba("#a78bfa", 0.10),
                             hovertemplate="Recall %{x:.2f}<br>Precision %{y:.2f}<extra></extra>"), 1, 2)
    fig.add_hline(y=y.mean(), line=dict(color=C["muted"], dash="dot", width=1), row=1, col=2)
    fig.update_xaxes(title_text="False-positive rate", row=1, col=1)
    fig.update_yaxes(title_text="True-positive rate", row=1, col=1)
    fig.update_xaxes(title_text="Recall", row=1, col=2)
    fig.update_yaxes(title_text="Precision", row=1, col=2)
    for a in fig.layout.annotations:
        a.font = dict(color=C["text"], size=13)
    return base(fig, 360)


def calibration_chart(y: np.ndarray, p: np.ndarray) -> go.Figure:
    frac, mean_pred = calibration_curve(y, p, n_bins=10, strategy="quantile")
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Perfect", line=dict(color=C["muted"], dash="dot", width=1)))
    fig.add_trace(go.Scatter(x=mean_pred, y=frac, mode="lines+markers", name="Model", line=dict(color=C["green"], width=2.5),
                             marker=dict(size=9, line=dict(color="#0f1324", width=2), color=C["green"]),
                             hovertemplate="Predicted %{x:.1%}<br>Actual %{y:.1%}<extra></extra>"))
    fig.update_xaxes(title="Predicted churn probability", tickformat=".0%")
    fig.update_yaxes(title="Observed churn rate", tickformat=".0%")
    return base(fig, 340)


def gains_chart(y: np.ndarray, p: np.ndarray) -> go.Figure:
    order = np.argsort(-p)
    cum = np.cumsum(y[order]) / max(y.sum(), 1)
    x = np.arange(1, len(y) + 1) / len(y)
    step = max(1, len(x) // 200)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Random targeting", line=dict(color=C["muted"], dash="dot", width=1)))
    fig.add_trace(go.Scatter(x=np.r_[0, x[::step]], y=np.r_[0, cum[::step]], mode="lines", name="Model ranking", line=dict(color=C["churn"], width=2.8),
                             fill="tonexty", fillcolor=hex_rgba("#fb7185", 0.10),
                             hovertemplate="Contact top %{x:.0%}<br>Capture %{y:.0%} of churners<extra></extra>"))
    fig.update_xaxes(title="% of customers contacted (riskiest first)", tickformat=".0%")
    fig.update_yaxes(title="% of churners captured", tickformat=".0%")
    return base(fig, 340)


def confusion_chart(tn: int, fp: int, fn: int, tp: int) -> go.Figure:
    z = [[tn, fp], [fn, tp]]
    labels = [["True negative", "False positive"], ["False negative", "True positive"]]
    text = [[f"<b style='font-size:20px'>{z[i][j]:,}</b><br>{labels[i][j]}" for j in range(2)] for i in range(2)]
    fig = go.Figure(go.Heatmap(z=[[tn, fp], [fn, tp]], x=["Predicted stay", "Predicted churn"], y=["Actually stayed", "Actually churned"],
                               text=text, texttemplate="%{text}", colorscale=SEQ, showscale=False, xgap=4, ygap=4,
                               hovertemplate="%{y} / %{x}: %{z:,}<extra></extra>", textfont=dict(color="#fff")))
    fig.update_yaxes(autorange="reversed")
    return base(fig, 340, legend=False)


def threshold_sweep(y: np.ndarray, p: np.ndarray, thr: float) -> go.Figure:
    ts = np.linspace(0.02, 0.95, 94)
    pr, rc, f1 = [], [], []
    for t in ts:
        pred = p >= t
        tp = (pred & (y == 1)).sum()
        prec = tp / max(pred.sum(), 1)
        rec = tp / max((y == 1).sum(), 1)
        pr.append(prec), rc.append(rec), f1.append(2 * prec * rec / max(prec + rec, 1e-9))
    fig = go.Figure()
    for name, ys, col in (("Precision", pr, C["violet"]), ("Recall", rc, C["stay"]), ("F1", f1, C["green"])):
        fig.add_trace(go.Scatter(x=ts, y=ys, mode="lines", name=name, line=dict(color=col, width=2.4),
                                 hovertemplate=f"{name} %{{y:.2f}} @ threshold %{{x:.2f}}<extra></extra>"))
    fig.add_vline(x=thr, line=dict(color=C["amber"], dash="dot", width=1.5), annotation_text="chosen", annotation_font_color=C["amber"])
    fig.update_xaxes(title="Decision threshold")
    fig.update_yaxes(range=[0, 1.02])
    return base(fig, 340)


# ------------------------------------------------------------------------------ SHAP
def shap_bar(imp: pd.DataFrame, labeler, top: int = 15) -> go.Figure:
    d = imp.head(top).iloc[::-1]
    lab = [labeler(f) for f in d["feature"]]
    fig = go.Figure(go.Bar(x=d["mean_abs_shap"], y=lab, orientation="h",
                           marker=dict(color=d["mean_abs_shap"], colorscale=SEQ),
                           text=[f"{v:.3f}" for v in d["mean_abs_shap"]], textposition="outside", textfont=dict(color=C["text"]),
                           hovertemplate="<b>%{y}</b><br>mean |SHAP| %{x:.4f}<extra></extra>"))
    fig.update_xaxes(title="mean |SHAP value|  (average impact on churn prediction)", range=[0, d["mean_abs_shap"].max() * 1.18])
    fig.update_yaxes(automargin=True)
    return base(fig, max(320, 30 * len(d) + 80), legend=False)


def shap_beeswarm(values: np.ndarray, feats: pd.DataFrame, labeler, top: int = 12, max_points: int = 700, seed: int = 0) -> go.Figure:
    rng = np.random.default_rng(seed)
    order = np.argsort(-np.abs(values).mean(0))[:top][::-1]
    n = len(values)
    pick = rng.choice(n, min(n, max_points), replace=False)
    fig = go.Figure()
    for pos, j in enumerate(order):
        v = values[pick, j]
        f = feats.iloc[pick, j].to_numpy(float)
        lo, hi = np.nanpercentile(f, [5, 95])
        norm = np.clip((f - lo) / (hi - lo), 0, 1) if hi > lo else np.full_like(f, 0.5)
        fig.add_trace(go.Scatter(
            x=v, y=pos + rng.uniform(-0.32, 0.32, len(v)), mode="markers", showlegend=False,
            marker=dict(size=6, color=norm, colorscale=[[0, "#22d3ee"], [0.5, "#a78bfa"], [1, "#fb7185"]], cmin=0, cmax=1, opacity=0.75,
                        line=dict(width=0)),
            customdata=np.c_[f], hovertemplate=f"<b>{labeler(feats.columns[j])}</b><br>value %{{customdata[0]:.3g}}<br>SHAP %{{x:+.3f}}<extra></extra>"))
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers", marker=dict(colorscale=[[0, "#22d3ee"], [0.5, "#a78bfa"], [1, "#fb7185"]],
                                                                          cmin=0, cmax=1, color=[0], showscale=True,
                                                                          colorbar=dict(title=dict(text="Feature value", side="right"), thickness=10,
                                                                                        tickvals=[0, 1], ticktext=["Low", "High"], outlinewidth=0,
                                                                                        tickfont=dict(color=C["muted"]))), showlegend=False))
    fig.add_vline(x=0, line=dict(color=C["line"], width=1))
    fig.update_yaxes(tickmode="array", tickvals=list(range(len(order))), ticktext=[labeler(feats.columns[j]) for j in order], automargin=True,
                     gridcolor="rgba(255,255,255,0.04)")
    fig.update_xaxes(title="SHAP value  (← lowers churn risk | raises churn risk →)")
    return base(fig, max(380, 38 * len(order) + 90), legend=False)


def shap_dependence(values: np.ndarray, feats: pd.DataFrame, feature: str, color_feature: str | None, labeler) -> go.Figure:
    j = list(feats.columns).index(feature)
    x, y = feats.iloc[:, j].to_numpy(float), values[:, j]
    marker = dict(size=7, opacity=0.75, line=dict(width=0))
    if color_feature and color_feature in feats.columns:
        c = feats[color_feature].to_numpy(float)
        marker.update(color=c, colorscale=[[0, "#22d3ee"], [0.5, "#a78bfa"], [1, "#fb7185"]],
                      colorbar=dict(title=dict(text=labeler(color_feature), side="right"), thickness=10, outlinewidth=0, tickfont=dict(color=C["muted"])))
    else:
        marker.update(color=C["violet"])
    fig = go.Figure(go.Scatter(x=x, y=y, mode="markers", marker=marker,
                               hovertemplate=f"{labeler(feature)} %{{x:.3g}}<br>SHAP %{{y:+.3f}}<extra></extra>"))
    fig.add_hline(y=0, line=dict(color=C["line"], width=1))
    fig.update_xaxes(title=labeler(feature))
    fig.update_yaxes(title="SHAP value")
    return base(fig, 380, legend=False)


def waterfall(base_value: float, shap_vals: np.ndarray, names: list[str], final_out: float, unit: str, top: int = 9) -> go.Figure:
    order = np.argsort(-np.abs(shap_vals))
    keep, rest = order[:top], order[top:]
    labels = [names[i] for i in keep]
    vals = [float(shap_vals[i]) for i in keep]
    if len(rest):
        labels.append(f"{len(rest)} other features")
        vals.append(float(shap_vals[rest].sum()))
    fig = go.Figure(go.Waterfall(
        orientation="h", measure=["relative"] * len(vals) + ["total"], y=labels + ["Model output"], x=vals + [0],
        base=base_value, connector=dict(line=dict(color=C["line"], width=1)),
        increasing=dict(marker=dict(color=C["churn"])), decreasing=dict(marker=dict(color=C["green"])),
        totals=dict(marker=dict(color=C["violet"])), text=[f"{v:+.2f}" for v in vals] + [f"{final_out:.2f}"], textposition="outside",
        textfont=dict(color=C["text"]), hovertemplate="%{y}<br>%{x:+.3f}<extra></extra>"))
    fig.add_vline(x=base_value, line=dict(color=C["muted"], dash="dot", width=1), annotation_text="average customer", annotation_font_color=C["muted"])
    fig.update_yaxes(autorange="reversed", automargin=True)
    fig.update_xaxes(title=f"model output ({unit})")
    return base(fig, max(360, 38 * len(labels) + 110), legend=False)


# ------------------------------------------------------------------------------ business
def risk_histogram(p: np.ndarray, thr: float | None = None) -> go.Figure:
    edges = [0, 0.15, 0.35, 0.60, 1.0001]
    names = ["Low", "Medium", "High", "Critical"]
    cols = [C["green"], C["stay"], C["amber"], C["churn"]]
    cnt = np.histogram(p, bins=edges)[0]
    fig = go.Figure(go.Bar(x=names, y=cnt, marker=dict(color=cols), text=[f"{c:,}" for c in cnt], textposition="outside",
                           textfont=dict(color=C["text"]), hovertemplate="%{x}: %{y:,} customers<extra></extra>"))
    fig.update_yaxes(title="customers", range=[0, max(cnt) * 1.15 if len(cnt) else 1])
    return base(fig, 300, legend=False)


def roi_chart(curve: pd.DataFrame, best_idx: int) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=curve["pct_targeted"], y=curve["saved_value"], name="Revenue saved", mode="lines", line=dict(color=C["stay"], width=2.2),
                             hovertemplate="Contact top %{x:.0f}%<br>Revenue saved %{y:,.0f}<extra></extra>"))
    fig.add_trace(go.Scatter(x=curve["pct_targeted"], y=curve["cost"], name="Offer cost", mode="lines", line=dict(color=C["amber"], width=2.2),
                             hovertemplate="Contact top %{x:.0f}%<br>Cost %{y:,.0f}<extra></extra>"))
    fig.add_trace(go.Scatter(x=curve["pct_targeted"], y=curve["net_value"], name="Net value", mode="lines", line=dict(color=C["green"], width=3.2),
                             fill="tozeroy", fillcolor=hex_rgba("#34d399", 0.10), hovertemplate="Contact top %{x:.0f}%<br>Net %{y:,.0f}<extra></extra>"))
    b = curve.iloc[best_idx]
    fig.add_trace(go.Scatter(x=[b["pct_targeted"]], y=[b["net_value"]], mode="markers", name="Best point", marker=dict(size=13, color="#fff", line=dict(color=C["green"], width=3)),
                             hovertemplate="Optimal: contact top %{x:.0f}%<br>Net %{y:,.0f}<extra></extra>"))
    fig.update_xaxes(title="% of customers contacted (riskiest first)", ticksuffix="%")
    fig.update_yaxes(title="expected value")
    return base(fig, 380)
