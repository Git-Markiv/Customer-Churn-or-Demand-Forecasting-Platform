"""SHAP explainability helpers (global + per-customer), robust across model families."""
from __future__ import annotations

import warnings
from dataclasses import dataclass

import numpy as np
import pandas as pd
import shap
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore", module="shap")


@dataclass
class ShapBundle:
    values: np.ndarray          # (n, f) contribution of each feature to each prediction
    features: pd.DataFrame      # (n, f) model-input feature values (what SHAP explains)
    base_value: float           # expected model output over the background data
    unit: str                   # 'log-odds' or 'probability'
    row_ids: np.ndarray         # customer ids of the explained rows


def make_explainer(model, background: pd.DataFrame):
    """Return (explainer, output-unit) for any model in the zoo."""
    if isinstance(model, LogisticRegression):
        return shap.LinearExplainer(model, shap.maskers.Independent(background, max_samples=200)), "log-odds"
    if isinstance(model, RandomForestClassifier):
        return shap.TreeExplainer(model), "probability"
    return shap.TreeExplainer(model), "log-odds"


def _positive_class(sv) -> np.ndarray:
    if isinstance(sv, list):
        sv = sv[1] if len(sv) == 2 else sv[0]
    sv = np.asarray(sv)
    return sv[:, :, 1] if sv.ndim == 3 else sv


def _base_value(explainer) -> float:
    ev = np.ravel(explainer.expected_value)
    return float(ev[-1])


def explain_rows(pipe: Pipeline, X: pd.DataFrame, background: pd.DataFrame, row_ids: np.ndarray,
                 max_rows: int = 3000, seed: int = 42) -> tuple[ShapBundle, object]:
    """SHAP values for (a sample of) the rows of X using a fitted pipeline."""
    if len(X) > max_rows:
        pos = np.sort(np.random.default_rng(seed).choice(len(X), max_rows, replace=False))
        X, row_ids = X.iloc[pos], np.asarray(row_ids)[pos]
    Xt = pipe[:-1].transform(X)
    bg = pipe[:-1].transform(background) if background is not None else Xt
    explainer, unit = make_explainer(pipe[-1], bg)
    values = _positive_class(explainer.shap_values(Xt))
    return ShapBundle(values, Xt.reset_index(drop=True), _base_value(explainer), unit, np.asarray(row_ids)), explainer


def explain_single(pipe: Pipeline, explainer, row: pd.DataFrame) -> tuple[np.ndarray, pd.Series, float, float]:
    """(shap values, transformed feature row, base value, predicted probability) for one customer."""
    Xt = pipe[:-1].transform(row)
    sv = _positive_class(explainer.shap_values(Xt))[0]
    proba = float(pipe.predict_proba(row)[0, 1])
    return sv, Xt.iloc[0], _base_value(explainer), proba


def global_importance(bundle: ShapBundle, meta: pd.DataFrame | None = None, by_source: bool = False) -> pd.DataFrame:
    imp = pd.DataFrame({"feature": bundle.features.columns, "mean_abs_shap": np.abs(bundle.values).mean(axis=0)})
    if by_source and meta is not None:                    # roll one-hot columns back up to their source column
        imp = imp.merge(meta[["feature", "source"]], on="feature", how="left")
        imp = imp.groupby("source", as_index=False)["mean_abs_shap"].sum().rename(columns={"source": "feature"})
    return imp.sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)
