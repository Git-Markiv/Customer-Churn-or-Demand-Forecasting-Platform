"""Central configuration for ChurnLens."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
SQL_DIR = ROOT / "sql"
ARTIFACT_DIR = ROOT / "artifacts"

DEMO_DB_PATH = DATA_DIR / "demo_churn.db"
DEMO_CSV_PATH = DATA_DIR / "demo_customers_flat.csv"

RANDOM_STATE = 42
TEST_SIZE = 0.2
CV_FOLDS = 5

# Demo "as of" date: the snapshot date used to compute tenure/recency features.
SNAPSHOT_DATE = "2026-09-30"

# Names used internally once any dataset has been standardised.
TARGET = "churn"
ID_COL = "customer_id"

# Colour system shared by Plotly charts and the CSS theme.
PALETTE = {
    "bg": "#070912",
    "panel": "#0f1324",
    "panel_2": "#151a31",
    "border": "rgba(255,255,255,0.08)",
    "text": "#e8ebf7",
    "muted": "#8f97b8",
    "violet": "#8b5cf6",
    "indigo": "#6366f1",
    "cyan": "#22d3ee",
    "emerald": "#34d399",
    "amber": "#fbbf24",
    "rose": "#fb7185",
}
