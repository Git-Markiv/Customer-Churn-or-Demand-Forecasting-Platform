"""ChurnLens: customer churn intelligence platform."""

__version__ = "1.0.0"
