"""Model zoo, cross-validated comparison, hyper-parameter tuning and hold-out evaluation."""
from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd
from scipy.stats import loguniform, randint, uniform
from sklearn.base import clone
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss, confusion_matrix,
                             f1_score, log_loss, precision_recall_curve, precision_score, recall_score,
                             roc_auc_score)
from sklearn.model_selection import (RandomizedSearchCV, StratifiedKFold, cross_val_predict, cross_validate)
from sklearn.pipeline import Pipeline

from .features import build_pipeline

try:
    from xgboost import XGBClassifier
except Exception:                                      # pragma: no cover
    XGBClassifier = None
try:
    from lightgbm import LGBMClassifier
except Exception:                                      # pragma: no cover
    LGBMClassifier = None

warnings.filterwarnings("ignore", category=UserWarning)

SCORING = {"roc_auc": "roc_auc", "pr_auc": "average_precision", "f1": "f1", "precision": "precision",
           "recall": "recall", "brier": "neg_brier_score", "logloss": "neg_log_loss"}
METRIC_LABELS = {"roc_auc": "ROC-AUC", "pr_auc": "PR-AUC", "f1": "F1", "precision": "Precision",
                 "recall": "Recall", "brier": "Brier", "logloss": "Log-loss"}
TREE_MODELS = {"Random Forest", "Gradient Boosting", "XGBoost", "LightGBM"}


@dataclass
class ModelSpec:
    factory: Callable[[int], object]
    space: dict
    scale: bool = False
    blurb: str = ""


def _specs() -> dict[str, ModelSpec]:
    specs: dict[str, ModelSpec] = {
        "Logistic Regression": ModelSpec(
            lambda s: LogisticRegression(max_iter=3000, random_state=s),
            {"model__C": loguniform(1e-3, 1e2)}, scale=True,
            blurb="Linear baseline - fast, transparent, needs scaled inputs."),
        "Random Forest": ModelSpec(
            lambda s: RandomForestClassifier(n_estimators=300, n_jobs=1, random_state=s),
            {"model__n_estimators": randint(150, 450), "model__max_depth": [None, 6, 8, 12, 16],
             "model__min_samples_leaf": randint(1, 25), "model__max_features": ["sqrt", 0.3, 0.5]},
            blurb="Bagged decision trees - robust, low variance."),
        "Gradient Boosting": ModelSpec(
            lambda s: GradientBoostingClassifier(random_state=s),
            {"model__n_estimators": randint(100, 350), "model__learning_rate": loguniform(0.02, 0.2),
             "model__max_depth": randint(2, 5), "model__subsample": uniform(0.6, 0.4),
             "model__min_samples_leaf": randint(5, 40)},
            blurb="Classic sklearn boosting - strong but slower."),
    }
    if XGBClassifier is not None:
        specs["XGBoost"] = ModelSpec(
            lambda s: XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=4, subsample=0.9,
                                    colsample_bytree=0.8, tree_method="hist", eval_metric="logloss",
                                    n_jobs=1, random_state=s, verbosity=0),
            {"model__n_estimators": randint(150, 550), "model__learning_rate": loguniform(0.02, 0.2),
             "model__max_depth": randint(2, 7), "model__subsample": uniform(0.6, 0.4),
             "model__colsample_bytree": uniform(0.5, 0.5), "model__min_child_weight": randint(1, 10),
             "model__reg_lambda": loguniform(0.1, 20)},
            blurb="Regularised gradient boosting - the tabular-data workhorse.")
    if LGBMClassifier is not None:
        specs["LightGBM"] = ModelSpec(
            lambda s: LGBMClassifier(n_estimators=300, learning_rate=0.05, num_leaves=31, subsample=0.9,
                                     subsample_freq=1, colsample_bytree=0.8, n_jobs=1, random_state=s,
                                     verbose=-1),
            {"model__n_estimators": randint(150, 550), "model__learning_rate": loguniform(0.02, 0.2),
             "model__num_leaves": randint(8, 64), "model__min_child_samples": randint(10, 60),
             "model__subsample": uniform(0.6, 0.4), "model__colsample_bytree": uniform(0.5, 0.5),
             "model__reg_lambda": loguniform(0.1, 20)},
            blurb="Leaf-wise histogram boosting - very fast on large tables.")
    return specs


MODEL_SPECS = _specs()


def available_models() -> list[str]:
    return list(MODEL_SPECS)


def make_pipeline(name: str, X: pd.DataFrame, seed: int, params: dict | None = None,
                  id_cols=()) -> Pipeline:
    spec = MODEL_SPECS[name]
    est = spec.factory(seed)
    if params:
        est.set_params(**{k.replace("model__", ""): v for k, v in params.items()})
    return build_pipeline(est, X, scale=spec.scale, id_cols=id_cols)


def _cv(folds: int, seed: int) -> StratifiedKFold:
    return StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)


def _summarise(scores: dict, prefix: str = "test_") -> dict:
    out = {}
    for k in SCORING:
        vals = np.asarray(scores[f"{prefix}{k}"], dtype=float)
        if k in ("brier", "logloss"):
            vals = -vals
        out[k], out[f"{k}_std"] = float(vals.mean()), float(vals.std())
    return out


# ------------------------------------------------------------------------------ comparison
def compare_models(X: pd.DataFrame, y: pd.Series, names: list[str], folds: int, seed: int,
                   progress: Callable[[str], None] | None = None) -> pd.DataFrame:
    rows = []
    for name in names:
        if progress:
            progress(f"Cross-validating {name}")
        pipe = make_pipeline(name, X, seed)
        t0 = time.time()
        res = cross_validate(pipe, X, y, cv=_cv(folds, seed), scoring=SCORING, n_jobs=-1)
        rows.append({"model": name, "stage": "Baseline", **_summarise(res),
                     "fit_seconds": float(np.mean(res["fit_time"])), "wall_seconds": time.time() - t0,
                     "params": {}})
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------ tuning
@dataclass
class TuneResult:
    name: str
    best_params: dict
    summary: dict
    trials: pd.DataFrame
    seconds: float = 0.0


def tune_model(name: str, X: pd.DataFrame, y: pd.Series, n_iter: int, folds: int, seed: int,
               metric: str = "pr_auc") -> TuneResult:
    spec = MODEL_SPECS[name]
    pipe = make_pipeline(name, X, seed)
    n_iter = max(4, min(n_iter, 14 if name == "Logistic Regression" else n_iter))
    t0 = time.time()
    search = RandomizedSearchCV(pipe, spec.space, n_iter=n_iter, scoring=SCORING, refit=metric,
                                cv=_cv(folds, seed), n_jobs=-1, random_state=seed, error_score="raise")
    search.fit(X, y)
    cvr = search.cv_results_
    i = search.best_index_
    summary = {}
    for k in SCORING:
        mean, std = cvr[f"mean_test_{k}"][i], cvr[f"std_test_{k}"][i]
        summary[k] = float(-mean if k in ("brier", "logloss") else mean)
        summary[f"{k}_std"] = float(std)
    params = {k.replace("model__", ""): (v.item() if hasattr(v, "item") else v)
              for k, v in search.best_params_.items()}
    trials = pd.DataFrame({"trial": np.arange(1, n_iter + 1), "score": cvr[f"mean_test_{metric}"],
                           "std": cvr[f"std_test_{metric}"],
                           **{k.replace("param_model__", ""): cvr[k] for k in cvr if k.startswith("param_")}})
    return TuneResult(name, params, summary, trials, time.time() - t0)


# ------------------------------------------------------------------------------ evaluation
def best_f1_threshold(y_true: np.ndarray, proba: np.ndarray) -> float:
    p, r, t = precision_recall_curve(y_true, proba)
    f1 = 2 * p[:-1] * r[:-1] / np.clip(p[:-1] + r[:-1], 1e-12, None)
    return float(t[int(np.nanargmax(f1))]) if len(t) else 0.5


def threshold_metrics(y_true: np.ndarray, proba: np.ndarray, thr: float) -> dict:
    pred = (proba >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {"threshold": float(thr), "accuracy": accuracy_score(y_true, pred),
            "precision": precision_score(y_true, pred, zero_division=0),
            "recall": recall_score(y_true, pred, zero_division=0), "f1": f1_score(y_true, pred, zero_division=0),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def holdout_metrics(y_true: np.ndarray, proba: np.ndarray) -> dict:
    n_top = max(1, int(round(0.10 * len(y_true))))
    top = np.argsort(-proba)[:n_top]
    base = y_true.mean()
    return {"roc_auc": roc_auc_score(y_true, proba), "pr_auc": average_precision_score(y_true, proba),
            "brier": brier_score_loss(y_true, proba), "logloss": log_loss(y_true, np.clip(proba, 1e-6, 1 - 1e-6)),
            "base_rate": float(base), "lift_top10": float(y_true[top].mean() / base) if base else np.nan,
            "capture_top10": float(y_true[top].sum() / max(y_true.sum(), 1))}


@dataclass
class FinalFit:
    pipeline: Pipeline
    proba_test: np.ndarray
    y_test: np.ndarray
    threshold: float
    holdout: dict
    at_threshold: dict
    oof_train: np.ndarray = field(repr=False, default=None)


def fit_and_evaluate(name: str, params: dict, X_train, y_train, X_test, y_test, X_schema, folds: int,
                     seed: int) -> FinalFit:
    template = make_pipeline(name, X_schema, seed, params)
    oof = cross_val_predict(clone(template), X_train, y_train, cv=_cv(folds, seed),
                            method="predict_proba", n_jobs=-1)[:, 1]
    thr = best_f1_threshold(y_train.to_numpy(), oof)
    pipe = clone(template).fit(X_train, y_train)
    proba = pipe.predict_proba(X_test)[:, 1]
    yt = y_test.to_numpy()
    return FinalFit(pipe, proba, yt, thr, holdout_metrics(yt, proba), threshold_metrics(yt, proba, thr), oof)


def oof_probabilities(name: str, params: dict, X: pd.DataFrame, y: pd.Series, folds: int, seed: int) -> np.ndarray:
    """Honest out-of-fold churn probability for *every* customer."""
    template = make_pipeline(name, X, seed, params)
    return cross_val_predict(template, X, y, cv=_cv(folds, seed), method="predict_proba", n_jobs=-1)[:, 1]


def fit_full(name: str, params: dict, X: pd.DataFrame, y: pd.Series, seed: int) -> Pipeline:
    return make_pipeline(name, X, seed, params).fit(X, y)
