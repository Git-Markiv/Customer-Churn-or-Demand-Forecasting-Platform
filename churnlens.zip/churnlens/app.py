"""ChurnLens - premium Streamlit dashboard.   Run:  streamlit run app.py"""
from __future__ import annotations

import warnings

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import streamlit as st

from src import charts as ch
from src import ui
from src.config import ID_COL, TARGET
from src.db import default_custom_query, read_sql_file, run_user_sql
from src.explain import explain_single, global_importance, make_explainer
from src.insights import (customer_reasons, format_value, pretty_name, recommend_actions, risk_band, roi_curve)
from src.loader import (read_table, suggest_id, suggest_positive_value, suggest_revenue, suggest_target)
from src.modeling import METRIC_LABELS, available_models, threshold_metrics
from src.pipeline import PRESETS, RunConfig, peek_cache, run_or_load

st.set_page_config(page_title="ChurnLens · Churn Intelligence", page_icon="📈", layout="wide",
                   initial_sidebar_state="expanded")
ui.inject_css()
PLOT_CFG = {"displayModeBar": False, "responsive": True}


def show(fig, key: str | None = None) -> None:
    st.plotly_chart(fig, width="stretch", config=PLOT_CFG, key=key)


def money(v: float) -> dict:
    """KPI value/suffix pair with compact units (CSS counters cannot print thousands separators)."""
    a = abs(v)
    if a >= 1e6:
        return dict(value=v / 1e6, decimals=2, suffix="M")
    if a >= 1e3:
        return dict(value=v / 1e3, decimals=1, suffix="k")
    return dict(value=v, decimals=0, suffix="")


# ============================================================================== sidebar
def sidebar() -> tuple[RunConfig | None, pd.DataFrame | None, bool]:
    """Returns (config, raw dataframe for custom mode, run_clicked)."""
    with st.sidebar:
        ui.brand()
        mode = st.radio("Data source", ["Demo dataset", "Upload my own"], label_visibility="collapsed", horizontal=True)
        raw, cfg_kwargs, ok = None, {}, True

        if mode == "Demo dataset":
            ui.callout("10,000 synthetic SaaS customers across <b>5 SQL tables</b> with realistic mess "
                       "(duplicates, typos, missing values, outliers).", "info", "🗄️")
            cfg_kwargs = dict(source="demo")
        else:
            up = st.file_uploader("Drop a CSV / Excel / Parquet file", type=["csv", "tsv", "txt", "xlsx", "xls", "json", "parquet"])
            if up is None:
                ui.callout("Upload any customer table with a <b>churn / attrition</b> column. "
                           "Telco, banking, SaaS - ChurnLens adapts.", "info", "📂")
                ok = False
            else:
                sig = (up.name, up.size)
                if st.session_state.get("_up_sig") != sig:
                    try:
                        st.session_state["_raw"] = read_table(up, up.name)
                        st.session_state["_up_sig"] = sig
                    except Exception as e:                       # noqa: BLE001
                        st.error(f"Could not read the file: {e}")
                        st.session_state.pop("_raw", None)
                raw = st.session_state.get("_raw")
                if raw is None:
                    ok = False
                else:
                    st.caption(f"**{len(raw):,}** rows × **{raw.shape[1]}** columns")
                    cols = list(raw.columns)
                    t_guess = suggest_target(raw)
                    target = st.selectbox("Churn column", cols, index=cols.index(t_guess) if t_guess in cols else 0)
                    vals = raw[target].dropna().unique().tolist()
                    if len(vals) > 12 or len(vals) < 2:
                        st.error("The churn column must have between 2 and 12 distinct values.")
                        ok = False
                        vals = vals[:12]
                    vals = sorted(vals, key=str)
                    pos_guess = suggest_positive_value(vals)
                    positive = st.selectbox("Value meaning 'churned'", vals, index=vals.index(pos_guess) if pos_guess in vals else 0,
                                            format_func=str)
                    id_opts = ["(none - auto)"] + [c for c in cols if c != target]
                    id_guess = suggest_id(raw)
                    id_col = st.selectbox("Customer ID column", id_opts, index=id_opts.index(id_guess) if id_guess in id_opts else 0)
                    rev_opts = ["(none)"] + [c for c in cols if c != target and pd.api.types.is_numeric_dtype(raw[c])]
                    rev_guess = suggest_revenue(raw)
                    rev = st.selectbox("Monthly revenue column (for ROI)", rev_opts, index=rev_opts.index(rev_guess) if rev_guess in rev_opts else 0)
                    flat = st.number_input("Flat monthly value if no revenue column", 1.0, 1e6, 100.0, step=10.0) if rev == "(none)" else 100.0
                    with st.expander("Advanced · SQL over your data"):
                        st.caption("Your file is loaded as table `data`. Join, filter or engineer features with SQL before modelling.")
                        sql = st.text_area("SQL", default_custom_query(cols), height=150, label_visibility="collapsed")
                    cfg_kwargs = dict(source="custom", target_col=target, positive_value=positive,
                                      id_col=None if id_col.startswith("(none") else id_col,
                                      revenue_col=None if rev == "(none)" else rev, default_monthly_value=float(flat),
                                      sql_query=sql.strip() or None)

        st.markdown("---")
        preset = st.select_slider("Compute budget", list(PRESETS), value="Quick",
                                  help="Quick ≈ 30 s · Balanced ≈ 1–2 min · Thorough ≈ 4+ min (demo data, 2 CPU cores)")
        with st.expander("Model settings"):
            models = st.multiselect("Models to compare", available_models(), default=available_models())
            metric = st.selectbox("Select winner by", ["pr_auc", "roc_auc", "f1"], format_func=lambda m: METRIC_LABELS[m],
                                  help="PR-AUC is the most honest metric for imbalanced churn data.")
            test_size = st.slider("Hold-out share", 0.1, 0.4, 0.2, 0.05)
            seed = st.number_input("Random seed", 0, 9999, 42)
        run = st.button("⚡  Run analysis", type="primary", width="stretch", disabled=not ok)
        st.caption("Everything runs locally. Results are cached on disk, so re-opening is instant.")
    if not ok:
        return None, raw, False
    cfg = RunConfig(**cfg_kwargs, models=tuple(models), metric=metric, test_size=float(test_size), seed=int(seed), **PRESETS[preset])
    return cfg, raw, run


# ============================================================================== run
def execute(cfg: RunConfig, raw: pd.DataFrame | None) -> None:
    box = st.empty()
    bar = st.progress(0.0)
    note = st.empty()

    def cb(frac: float, msg: str) -> None:
        bar.progress(min(max(frac, 0.0), 1.0))
        note.markdown(f"<div class='callout info'><div class='ic'>⚙️</div><div><b>{ui.esc(msg)}</b> · {frac * 100:.0f}%</div></div>",
                      unsafe_allow_html=True)

    try:
        res, cached = run_or_load(cfg, raw, cb)
        st.session_state.update(res=res, cached=cached, cfg=cfg, err=None)
    except Exception as e:                                       # noqa: BLE001
        st.session_state["err"] = str(e)
    finally:
        box.empty(), bar.empty(), note.empty()


def explainer_for(res):
    key = f"expl-{res.run_id}"
    if key not in st.session_state:
        bg = res.final.pipeline[:-1].transform(res.X.iloc[res.train_idx].sample(min(300, len(res.train_idx)), random_state=1))
        st.session_state[key] = make_explainer(res.final.pipeline[-1], bg)      # (explainer, unit)
    return st.session_state[key][0]


# ============================================================================== landing
def landing(err: str | None) -> None:
    ui.hero("Know who will churn - and why.",
            "A full churn-prediction workflow in one place: SQL extraction, cleaning, EDA, feature engineering, five models with "
            "cross-validation and tuning, then SHAP explanations you can act on.",
            [("SQL", "extract"), ("Models", "5 + tuning"), ("Explain", "SHAP"), ("Data", "demo or yours")])
    if err:
        ui.callout(f"<b>The analysis could not run.</b> {ui.esc(err)}", "bad")
    ui.section("How it works")
    ui.steps([("Extract", "SQL joins 5 tables into one row per customer"), ("Clean", "Dedupe, fix labels, null impossible values"),
              ("Engineer", "Trends, ratios, billing health, flags"), ("Compare", "5 models · stratified k-fold CV"),
              ("Tune", "Randomized search on the top models"), ("Explain", "Global + per-customer SHAP")])
    st.markdown("")
    ui.callout("Pick <b>Demo dataset</b> or upload your own file in the sidebar, then press <b>Run analysis</b>.", "info", "👈")


# ============================================================================== tabs
def tab_overview(res) -> None:
    sc, fin = res.scores, res.final
    active = sc[sc["churn"] == 0]
    at_risk = float((active["proba"] * active["annual_value"]).sum())
    h = fin.holdout
    ui.kpi_row([
        dict(label="Customers analysed", value=len(sc) / 1000, decimals=1, suffix="k", note=f"{len(sc):,} after cleaning", accent="#8b5cf6"),
        dict(label="Churn rate", value=sc["churn"].mean() * 100, decimals=1, suffix="%", note=f"{int(sc['churn'].sum()):,} churned", accent="#fb7185"),
        dict(label="Hold-out ROC-AUC", value=h["roc_auc"], decimals=2, note=f"{res.best_name} · {res.best_stage.lower()}", accent="#22d3ee"),
        dict(label="Hold-out PR-AUC", value=h["pr_auc"], decimals=2, note=f"baseline {h['base_rate']:.2f}", accent="#a78bfa"),
        dict(label="Top-10% lift", value=h["lift_top10"], decimals=1, suffix="×", note=f"captures {h['capture_top10']:.0%} of churners", accent="#34d399"),
        dict(label="Revenue at risk", **money(at_risk),
             note="active customers · prob × annual value", accent="#fbbf24"),
    ])
    for n in res.notes:
        ui.callout(ui.esc(n), "warn")

    c1, c2 = st.columns([1, 1.25], gap="large")
    with c1:
        ui.section("Churn at a glance", "Share of customers who left.")
        show(ch.churn_donut(float(sc["churn"].mean())), "ov-donut")
    with c2:
        ui.section("Risk distribution", "Out-of-fold churn probabilities for every customer, bucketed.")
        show(ch.risk_histogram(sc["proba"].to_numpy()), "ov-risk")

    imp = global_importance(res.shap, res.meta, by_source=True)
    top = imp.head(3)["feature"].tolist()
    seg = _riskiest_segment(res)
    ui.section("What the model learned")
    lines = [f"<b>Top drivers of churn:</b> {', '.join(pretty_name(f) for f in top)}."]
    if seg:
        lines.append(f"<b>Riskiest segment:</b> {seg}")
    lines.append(f"<b>Validated honestly:</b> {res.best_name} chosen by {METRIC_LABELS[res.config.metric]} from {len(res.leaderboard)} "
                 f"cross-validated candidates, then scored once on {len(res.test_idx):,} unseen customers.")
    ui.callout("<br>".join(lines), "good", "🧠")
    st.caption(f"Pipeline finished in {res.timings.get('total', 0):.0f}s · run id `{res.run_id}` · "
               f"{'loaded from cache' if st.session_state.get('cached') else 'computed just now'}")


def _riskiest_segment(res) -> str | None:
    best = None
    sc = res.scores.assign(_i=np.arange(len(res.scores)))
    for c in res.X.columns:
        s = res.X[c]
        if (pd.api.types.is_object_dtype(s) or pd.api.types.is_string_dtype(s)) and 2 <= s.nunique() <= 12:
            g = pd.DataFrame({"v": s.to_numpy(), "y": res.y.to_numpy()}).groupby("v")["y"].agg(["mean", "size"])
            g = g[g["size"] >= 0.03 * len(s)]
            if len(g):
                v, r = g["mean"].idxmax(), g["mean"].max()
                if best is None or r > best[2]:
                    best = (c, v, r, int(g.loc[v, "size"]))
    if not best:
        return None
    return f"{pretty_name(best[0])} = <b>{ui.esc(best[1])}</b> churns at <b>{best[2]:.0%}</b> ({best[3]:,} customers) vs {res.y.mean():.0%} overall."


def tab_data(res) -> None:
    ui.section("1 · SQL extraction", "The modelling table is built in SQL: window functions de-duplicate customers and split usage into "
                                      "recent vs prior periods; conditional aggregates summarise support and billing.")
    st.code(res.sql_text, language="sql", line_numbers=True)
    k1, k2, k3 = st.columns(3)
    k1.metric("Rows extracted", f"{len(res.extracted):,}")
    k2.metric("Columns", f"{res.extracted.shape[1]}")
    k3.metric("Source", res.source_label.split("(")[0].strip())
    with st.expander("Preview extracted table", expanded=False):
        st.dataframe(res.extracted.head(200), width="stretch", hide_index=True)

    ui.section("SQL console", "Run your own read-only SELECT on the extracted table (exposed as `data`).")
    q = st.text_area("Query", "SELECT contract_type, COUNT(*) AS customers, ROUND(AVG(churn) * 100, 1) AS churn_pct\nFROM data\nGROUP BY 1\nORDER BY churn_pct DESC"
                     if "contract_type" in res.extracted.columns else default_custom_query(list(res.extracted.columns)[:6]),
                     height=130, key=f"sql-{res.run_id}", label_visibility="collapsed")
    if st.button("▶  Run query", key=f"runq-{res.run_id}"):
        try:
            out = run_user_sql(res.extracted, q)
            st.dataframe(out, width="stretch", hide_index=True)
        except Exception as e:                                   # noqa: BLE001
            st.error(str(e))

    ui.section("2 · Cleaning report", "Every automatic fix, with how many values it touched. Imputation happens inside the model "
                                      "pipeline, per CV fold, so nothing leaks from validation data.")
    r = res.report
    ui.kpi_row([dict(label="Rows", value=r.rows_after / 1000, decimals=1, suffix="k", note=f"from {r.rows_before:,}", accent="#22d3ee"),
                dict(label="Columns", value=r.cols_after, note=f"from {r.cols_before}", accent="#a78bfa"),
                dict(label="Missing cells", value=r.missing_after / 1000, decimals=1, suffix="k", note=f"{r.missing_before:,} before cleaning", accent="#fbbf24"),
                dict(label="Fixes applied", value=len([s for s in r.steps if s.kind != 'info']), note="distinct cleaning steps", accent="#34d399")])
    rep = r.to_frame().rename(columns={"step": "Step", "detail": "What & why", "affected": "Values", "kind": "Type"})
    st.dataframe(rep, width="stretch", hide_index=True,
                 column_config={"Values": st.column_config.ProgressColumn("Values touched", format="%d", min_value=0, max_value=max(int(rep["Values"].max()), 1))})
    st.download_button("⬇  Download cleaned dataset (CSV)", res.clean.to_csv(index=False).encode(), "churnlens_clean.csv", "text/csv")

    ui.section("3 · Feature engineering", "Created inside the scikit-learn pipeline so each CV fold learns features on its own training data.")
    eng = [c for c in res.meta["source"].unique() if c not in res.clean.columns]
    ui.callout(f"<b>{len(res.meta)}</b> model inputs from <b>{res.X.shape[1]}</b> cleaned columns. "
               f"Engineered: " + ", ".join(f"<code>{ui.esc(e)}</code>" for e in eng[:24]) + (" …" if len(eng) > 24 else ""), "info", "🛠️")


def tab_eda(res) -> None:
    df = res.clean
    cats = [c for c in df.columns if c not in (TARGET, ID_COL) and (df[c].dtype == object or str(df[c].dtype) in ("str", "string", "category", "bool") or df[c].nunique() <= 8)
            and 2 <= df[c].nunique() <= 40]
    nums = [c for c in df.select_dtypes("number").columns if c not in (TARGET,) and df[c].nunique() > 8]
    ui.section("Where does churn concentrate?", "Churn rate by segment. The dotted line is the overall average; bars above it are at-risk segments.")
    c1, c2 = st.columns([1, 1], gap="large")
    with c1:
        if cats:
            col = st.selectbox("Segment by", cats, key="eda-cat")
            show(ch.churn_by_category(df, col), f"eda-cat-{col}")
    with c2:
        if nums:
            col2 = st.selectbox("Numeric driver", nums, key="eda-num")
            show(ch.binned_churn(df, col2), f"eda-bin-{col2}")
    if nums:
        ui.section("Distributions by outcome", "Do churners look different from retained customers?")
        col3 = st.selectbox("Feature", nums, key="eda-dist", index=min(1, len(nums) - 1))
        show(ch.numeric_distribution(df, col3), f"eda-dist-{col3}")
    c3, c4 = st.columns([1.5, 1], gap="large")
    with c3:
        ui.section("Correlation map", "Top numeric features most correlated with churn.")
        if len(df.select_dtypes("number").columns) > 2:
            show(ch.correlation_heatmap(df), "eda-corr")
    with c4:
        ui.section("Missing values", "Left in place after cleaning; imputed inside CV.")
        if res.report.missing_by_col is not None and len(res.report.missing_by_col):
            show(ch.missing_bar(res.report.missing_by_col, len(df)), "eda-miss")
        else:
            ui.callout("No missing values remain.", "good")


def tab_models(res) -> None:
    lb = res.leaderboard
    best = lb.iloc[0]
    ui.section("Model comparison", f"{len(lb)} candidates scored with stratified cross-validation. The best top models are re-tuned with "
                                   "randomized search, and the winner is picked by " + METRIC_LABELS[res.config.metric] + ".")
    ui.callout(f"<b>{ui.esc(best['model'])}</b> ({best['stage'].lower()}) wins with CV {METRIC_LABELS[res.config.metric]} "
               f"<b>{best[res.config.metric]:.3f}</b> ± {best[res.config.metric + '_std']:.3f}.", "good", "🏆")
    metric = st.radio("Metric", ["pr_auc", "roc_auc", "f1", "recall", "precision"], horizontal=True, format_func=lambda m: METRIC_LABELS[m],
                      index=["pr_auc", "roc_auc", "f1", "recall", "precision"].index(res.config.metric) if res.config.metric in ("pr_auc", "roc_auc", "f1") else 0)
    c1, c2 = st.columns([1.4, 1], gap="large")
    with c1:
        show(ch.leaderboard_chart(lb, metric), f"lb-{metric}")
    with c2:
        show(ch.metric_radar(lb), "radar")
    tbl = lb[["rank", "model", "stage", "roc_auc", "pr_auc", "f1", "precision", "recall", "brier", "wall_seconds"]].copy()
    tbl["wall_seconds"] = tbl["wall_seconds"].round(1)
    st.dataframe(tbl.rename(columns={"wall_seconds": "time (s)", "roc_auc": "ROC-AUC", "pr_auc": "PR-AUC"}), width="stretch", hide_index=True,
                 column_config={"ROC-AUC": st.column_config.ProgressColumn(format="%.3f", min_value=0.5, max_value=1.0),
                                "PR-AUC": st.column_config.ProgressColumn(format="%.3f", min_value=0.0, max_value=1.0)})
    if res.tuning:
        ui.section("Hyper-parameter tuning", "Randomized search over each model's key parameters. Green line = best score found so far.")
        names = list(res.tuning)
        cols = st.columns(len(names), gap="large")
        for col, nm in zip(cols, names):
            with col:
                base = float(lb[(lb["model"] == nm) & (lb["stage"] == "Baseline")][res.config.metric].iloc[0])
                show(ch.tuning_trials(res.tuning[nm].trials, base, res.config.metric, nm), f"tune-{nm}")
                with st.expander(f"Best parameters · {nm}"):
                    st.json({k: (round(v, 5) if isinstance(v, float) else v) for k, v in res.tuning[nm].best_params.items()})


def tab_eval(res) -> None:
    f = res.final
    ui.section(f"Hold-out evaluation · {res.best_name}", f"Scored on {len(f.y_test):,} customers the model never saw during CV, tuning or fitting.")
    c1, c2 = st.columns([1.5, 1], gap="large")
    with c1:
        show(ch.roc_pr_curves(f.y_test, f.proba_test), "ev-roc")
    with c2:
        show(ch.calibration_chart(f.y_test, f.proba_test), "ev-cal")
    ui.section("Choose a decision threshold", "Moving the slider trades precision against recall. The default maximises F1 on out-of-fold training predictions.")
    thr = st.slider("Threshold (flag customers with churn probability ≥)", 0.05, 0.90, float(round(f.threshold, 2)), 0.01)
    m = threshold_metrics(f.y_test, f.proba_test, thr)
    ui.kpi_row([dict(label="Precision", value=m["precision"] * 100, decimals=1, suffix="%", note="of flagged customers truly churn", accent="#a78bfa"),
                dict(label="Recall", value=m["recall"] * 100, decimals=1, suffix="%", note="of churners are caught", accent="#22d3ee"),
                dict(label="F1", value=m["f1"], decimals=2, note="balance of the two", accent="#34d399"),
                dict(label="Customers flagged", value=m["tp"] + m["fp"], note=f"{m['fp']:,} false alarms", accent="#fbbf24")])
    c3, c4, c5 = st.columns(3, gap="large")
    with c3:
        show(ch.confusion_chart(m["tn"], m["fp"], m["fn"], m["tp"]), "ev-cm")
    with c4:
        show(ch.threshold_sweep(f.y_test, f.proba_test, thr), "ev-sweep")
    with c5:
        show(ch.gains_chart(f.y_test, f.proba_test), "ev-gain")


def tab_shap(res) -> None:
    b = res.shap
    lab = lambda f: pretty_name(f, res.meta)           # noqa: E731
    ui.section("Why does the model predict churn?", f"SHAP assigns each feature a contribution to every prediction. Computed on {len(b.values):,} unseen customers. "
                                                    f"Units: {b.unit} - positive pushes toward churn.")
    c1, c2 = st.columns([1, 1.25], gap="large")
    with c1:
        roll = st.toggle("Group one-hot columns by source feature", value=True)
        imp = global_importance(b, res.meta, by_source=roll)
        show(ch.shap_bar(imp, lambda f: pretty_name(f, res.meta), 15), f"shap-bar-{roll}")
    with c2:
        st.markdown("&nbsp;")
        show(ch.shap_beeswarm(b.values, b.features, lab, 12), "shap-bee")
    ui.callout("<b>Reading the swarm:</b> each dot is one customer. Right of zero = pushes toward churn. Red = a high feature value, cyan = low. "
               "e.g. red dots on the right mean <i>high values raise churn risk</i>.", "info", "📖")
    ui.section("How one feature changes the prediction", "Dependence plot: SHAP value vs feature value, coloured by a second feature to reveal interactions.")
    order = np.argsort(-np.abs(b.values).mean(0))
    feats = [b.features.columns[i] for i in order if b.features.iloc[:, i].nunique() > 2][:20] or list(b.features.columns[order[:10]])
    d1, d2 = st.columns(2)
    f1 = d1.selectbox("Feature", feats, format_func=lab, key="dep-f")
    f2 = d2.selectbox("Colour by", ["(none)"] + [x for x in feats if x != f1], format_func=lambda x: x if x == "(none)" else lab(x), key="dep-c")
    show(ch.shap_dependence(b.values, b.features, f1, None if f2 == "(none)" else f2, lab), f"dep-{f1}-{f2}")


def tab_customers(res) -> None:
    f = res.final
    pipe = f.pipeline
    X_te = res.X.iloc[res.test_idx].reset_index(drop=True)
    ids = res.ids.iloc[res.test_idx].reset_index(drop=True)
    proba = pd.Series(f.proba_test)
    order = proba.sort_values(ascending=False).index.tolist()
    ui.section("Customer explorer", "Pick any hold-out customer, see their risk score, the exact reasons behind it, and what to do about it.")
    pick = st.selectbox("Customer (sorted by churn risk)", order, format_func=lambda i: f"{ids[i]}  ·  {proba[i]:.0%} risk  ·  {'churned' if res.y.iloc[res.test_idx[i]] else 'active'}",
                        key="cust-pick")
    row = X_te.iloc[[pick]]
    explainer = explainer_for(res)
    sv, xt, base_val, p = explain_single(pipe, explainer, row)
    reasons = customer_reasons(sv, xt, res.meta, 8)
    band, color = risk_band(p)
    g1, g2 = st.columns([0.8, 1.6], gap="large")
    with g1:
        ui.gauge(p, band, color)
        actual = "Churned" if res.y.iloc[res.test_idx[pick]] else "Still active"
        st.markdown(f"<div style='text-align:center;margin-top:8px'>{ui.badge(actual, '#fb7185' if actual == 'Churned' else '#34d399')} "
                    f"<span style='color:#8f97b8;font-size:12px'>actual outcome</span></div>", unsafe_allow_html=True)
        st.markdown(f"<div style='text-align:center;color:#8f97b8;font-size:12.5px;margin-top:10px'>Average customer: {res.y.mean():.0%} · "
                    f"Annual value: <b style='color:#e8ebf7'>{res.annual_value[res.test_idx[pick]]:,.0f}</b></div>", unsafe_allow_html=True)
    with g2:
        ui.section("Top reasons", "Bars show each feature's push on this customer's risk. Red raises it, green lowers it.")
        ui.driver_rows(reasons.to_dict("records"))
    c3, c4 = st.columns([1.35, 1], gap="large")
    with c3:
        ui.section("Prediction breakdown")
        names = [pretty_name(n, res.meta) for n in xt.index]
        out_val = base_val + float(sv.sum())
        show(ch.waterfall(base_val, sv, names, out_val, explainer_unit(res)), f"wf-{pick}")
    with c4:
        ui.section("Recommended retention plays")
        ui.play_cards(recommend_actions(reasons, res.meta))

    ui.section("What-if simulator", "Change this customer's attributes and watch the churn probability and its drivers update live.")
    imp = global_importance(res.shap, res.meta, by_source=True)
    editable = [c for c in imp["feature"] if c in res.X.columns][:6]
    new = row.copy()
    cols = st.columns(3)
    for i, c in enumerate(editable):
        s = res.X[c]
        with cols[i % 3]:
            cur = row.iloc[0][c]
            if pd.api.types.is_numeric_dtype(s) and s.nunique() > 2:
                lo, hi = float(s.quantile(0.01)), float(s.quantile(0.99))
                curv = float(cur) if pd.notna(cur) else float(s.median())
                lo, hi = min(lo, curv), max(hi, curv)
                new[c] = st.slider(pretty_name(c), lo, hi, curv, (hi - lo) / 100 or 0.01, key=f"wi-{c}-{pick}")
            elif pd.api.types.is_numeric_dtype(s):
                new[c] = st.selectbox(pretty_name(c), sorted(s.dropna().unique()), index=sorted(s.dropna().unique()).index(cur) if cur in set(s.dropna()) else 0, key=f"wi-{c}-{pick}")
            else:
                opts = sorted(s.dropna().astype(str).unique())
                new[c] = st.selectbox(pretty_name(c), opts, index=opts.index(str(cur)) if str(cur) in opts else 0, key=f"wi-{c}-{pick}")
    p2 = float(pipe.predict_proba(new)[0, 1])
    sv2, xt2, _, _ = explain_single(pipe, explainer, new)
    b2, c2_ = risk_band(p2)
    delta = p2 - p
    w1, w2 = st.columns([0.8, 1.6], gap="large")
    with w1:
        ui.gauge(p2, b2, c2_)
        arrow = "▼" if delta < 0 else "▲"
        col = "#34d399" if delta < 0 else "#fb7185" if delta > 0 else "#8f97b8"
        st.markdown(f"<div style='text-align:center;margin-top:8px;font-weight:700;color:{col}'>{arrow} {delta * 100:+.1f} pts vs current</div>", unsafe_allow_html=True)
    with w2:
        ui.driver_rows(customer_reasons(sv2, xt2, res.meta, 6).to_dict("records"))


def explainer_unit(res) -> str:
    return res.shap.unit


def tab_action(res) -> None:
    sc = res.scores
    ui.section("Retention ROI planner", "Contact the riskiest customers first. Set what an offer costs and how often it works to find the best-sized campaign.")
    c1, c2, c3 = st.columns(3)
    unit_val = float(np.median(res.annual_value))
    cost = c1.number_input("Cost per retention offer", 0.0, 1e6, float(round(unit_val * 0.05, 0)), step=5.0)
    succ = c2.slider("Save rate when contacted", 0.05, 0.9, 0.30, 0.05)
    active_only = c3.toggle("Only active customers", value=True, help="Churned customers cannot be saved; target the ones still here.")
    pool = sc[sc["churn"] == 0] if active_only else sc
    curve = roi_curve(pool["proba"].to_numpy(), pool["annual_value"].to_numpy(), cost, succ)
    bi = int(curve["net_value"].idxmax())
    b = curve.iloc[bi]
    ui.kpi_row([dict(label="Best campaign size", value=b["pct_targeted"], decimals=0, suffix="%", note=f"{int(b['customers']):,} customers · risk ≥ {b['risk_cutoff']:.0%}", accent="#22d3ee"),
                dict(label="Net value", **money(b["net_value"]), note="expected, per year", accent="#34d399"),
                dict(label="Revenue saved", **money(b["saved_value"]), note="expected", accent="#a78bfa"),
                dict(label="Campaign cost", **money(b["cost"]), note=f"{cost:,.0f} per offer", accent="#fbbf24")])
    show(ch.roi_chart(curve, bi), "roi")
    ui.section("Priority call list", "Active customers ranked by expected loss (churn probability × annual value).")
    lst = pool[pool["churn"] == 0].assign(expected_loss=lambda d: d["proba"] * d["annual_value"]).sort_values("expected_loss", ascending=False)
    lst["risk"] = [risk_band(p)[0] for p in lst["proba"]]
    view = lst.head(500).rename(columns={ID_COL: "Customer", "proba": "Churn risk", "annual_value": "Annual value", "expected_loss": "Expected loss", "risk": "Band"})
    st.dataframe(view[["Customer", "Band", "Churn risk", "Annual value", "Expected loss"]], width="stretch", hide_index=True,
                 column_config={"Churn risk": st.column_config.ProgressColumn(format="percent", min_value=0, max_value=1),
                                "Annual value": st.column_config.NumberColumn(format="%.0f"), "Expected loss": st.column_config.NumberColumn(format="%.0f")})
    all_scores = sc.assign(risk_band=[risk_band(p)[0] for p in sc["proba"]]).rename(columns={"proba": "churn_probability"})
    st.download_button("⬇  Download all customer risk scores (CSV)", all_scores.to_csv(index=False).encode(), "churnlens_risk_scores.csv", "text/csv")


# ============================================================================== main
def main() -> None:
    cfg, raw, run = sidebar()
    if run and cfg is not None:
        execute(cfg, raw)
    elif "res" not in st.session_state and cfg is not None and cfg.source == "demo":
        cached = peek_cache(cfg, None)                # instant open if a demo run is already cached
        if cached is not None:
            st.session_state.update(res=cached, cached=True, cfg=cfg, err=None)

    res = st.session_state.get("res")
    if res is None:
        landing(st.session_state.get("err"))
        return
    if st.session_state.get("err"):
        ui.callout(f"<b>Last run failed:</b> {ui.esc(st.session_state['err'])}", "bad")

    c = res.config
    ui.hero("ChurnLens", "Customer churn intelligence: predict who leaves, understand why, and decide who to save first.",
            [("Dataset", res.source_label.split("(")[0].strip()), ("Customers", f"{len(res.scores):,}"),
             ("Churn", f"{res.scores['churn'].mean():.1%}"), ("Best model", res.best_name), ("ROC-AUC", f"{res.final.holdout['roc_auc']:.3f}")])
    tabs = st.tabs(["Overview", "Data & SQL", "EDA", "Models", "Evaluation", "Explain (SHAP)", "Customers", "Action plan"])
    for tab, fn in zip(tabs, (tab_overview, tab_data, tab_eda, tab_models, tab_eval, tab_shap, tab_customers, tab_action)):
        with tab:
            fn(res)


main()
