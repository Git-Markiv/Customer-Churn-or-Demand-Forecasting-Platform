# ChurnLens · Customer Churn Intelligence Platform

Predict who will churn, understand **why** (SHAP), and decide **who to save first** (ROI planner) —
in a dark, animated Streamlit dashboard. Works on the built-in demo warehouse **or your own CSV/Excel file**.

**Stack:** Pandas · NumPy · SQL (SQLite) · scikit-learn · XGBoost · LightGBM · SHAP · Streamlit · Plotly

## Run it in VS Code

1. Open this folder in VS Code (`File → Open Folder…`).
2. Open a terminal (`Ctrl + ` `) and run:

   ```bash
   python -m venv .venv
   .venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
   pip install -r requirements.txt
   python -m src.pipeline --demo --preset Quick    # optional: pre-build results (~1 min)
   streamlit run app.py
   ```
   Or just double-click `run.bat` (Windows) / run `./run.sh` (macOS/Linux).
3. Prefer the debugger? Press **F5** and pick *ChurnLens: Streamlit dashboard*.
4. Select the `.venv` interpreter when VS Code asks (Python 3.10+).

The browser opens at <http://localhost:8501>. The first time, choose **Demo dataset** and press **Run analysis**
(Quick ≈ 40 s, Balanced ≈ 5 min on 2 cores). Results are cached in `artifacts/cache/`, so later launches are instant.

## What it does

| Stage | Where | Details |
|---|---|---|
| **SQL extraction** | `sql/extract_features.sql` | 5 tables → 1 row per customer. Window functions (`ROW_NUMBER`) de-duplicate customers and split usage into recent vs prior months; conditional aggregates summarise support tickets and billing. |
| **Cleaning** | `src/cleaning.py` | Column names, whitespace, missing tokens, duplicates, text-numbers, dates, category typos/aliases, impossible values, outlier winsorising, junk columns — each step reported in the UI. |
| **EDA** | `app.py` · EDA tab | Churn by segment, binned driver curves, distributions by outcome, correlation map, missingness. |
| **Feature engineering** | `src/features.py` | A scikit-learn transformer (runs inside every CV fold): usage trends, per-seat intensity, price per seat, ticket rate, billing issue rate, missing-value flags. Calendar-date features are deliberately **not** created (they leak churn timing). |
| **Model comparison** | `src/modeling.py` | Logistic Regression, Random Forest, Gradient Boosting, XGBoost, LightGBM — stratified k-fold CV on ROC-AUC, PR-AUC, F1, precision, recall, Brier, log-loss. |
| **Tuning** | `src/modeling.py` | `RandomizedSearchCV` on the top models; winner chosen by PR-AUC (or your pick). |
| **Evaluation** | Evaluation tab | One-shot hold-out test, ROC/PR curves, calibration, gains, confusion matrix, interactive threshold. |
| **SHAP** | `src/explain.py` | Global importance, beeswarm, dependence plots, per-customer waterfall; works for linear, tree and boosted models. |
| **Action** | Customers + Action plan tabs | Plain-English reasons, retention plays, what-if simulator, ROI-optimal campaign size, downloadable risk scores. |

## Use your own dataset

Choose **Upload my own** in the sidebar and drop in a CSV / TSV / Excel / JSON / Parquet file.
ChurnLens auto-detects the churn column and its “churned” value (e.g. `Churn = Yes`), the ID column and a revenue column — change
any guess with the dropdowns. Optionally write SQL over your file (table name `data`) before modelling.

Requirements: ≥ 150 rows, ≥ 30 churned and ≥ 30 retained customers. Everything else is cleaned and encoded automatically.
A ready-made example is included: `data/sample_custom_dataset.csv` (target `Churn`, positive `Yes`, ID `customerID`, revenue `MonthlyCharges`). The classic IBM Telco churn CSV works with the same settings.

CLI equivalent:
```bash
python -m src.pipeline --csv my.csv --target Churn --positive Yes --id customerID --preset Balanced
```

## Project layout

```
app.py                 Streamlit dashboard (8 tabs)
src/
  config.py            paths, constants, palette
  data_gen.py          synthetic 5-table SaaS warehouse (+ injected data mess)
  db.py                SQL extraction + safe read-only SQL console
  loader.py            file reading, target / ID / revenue detection
  cleaning.py          reported, leak-safe cleaning
  features.py          FeatureEngineer + preprocessing pipeline
  modeling.py          model zoo, CV, tuning, thresholds, metrics
  explain.py           SHAP helpers
  insights.py          labels, reasons, retention plays, ROI curve
  pipeline.py          orchestration, caching, CLI
  ui.py / charts.py    animated CSS theme, components, Plotly figures
sql/                   schema.sql, extract_features.sql
tests/                 pytest sanity tests
```

## Notes on the demo data

The demo data is **synthetic**, generated with known churn drivers (contract type, usage momentum, support friction,
payment failures, renewal timing, tenure …) so SHAP has something genuine to find. Scores reflect that simulated world, not a real business.
Rebuild it any time with `python -c "from src.data_gen import build_demo_database as b; b(force=True)"`.

## Design notes

* **No leakage:** imputation, scaling, encoding and feature engineering are all inside the CV pipeline; features use only data
  available before the churn date; tuning never sees the hold-out set.
* **Honest scoring:** every customer's risk is an *out-of-fold* prediction.
* **Animations:** pure CSS (count-up KPIs, animated gauge, staggered reveals, ambient gradient orbs); respects `prefers-reduced-motion`.
