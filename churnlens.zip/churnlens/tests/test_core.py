"""Fast sanity tests: SQL extraction, cleaning, feature pipeline, SQL guard, custom-data path."""
import warnings

import numpy as np
import pandas as pd
import pytest

warnings.filterwarnings("ignore")

from src.cleaning import clean_dataframe  # noqa: E402
from src.data_gen import generate_demo_tables  # noqa: E402
from src.db import extract_demo_features, run_user_sql, validate_select  # noqa: E402
from src.loader import prepare_custom_frame, suggest_target  # noqa: E402
from src.modeling import make_pipeline  # noqa: E402


@pytest.fixture(scope="module")
def demo():
    df, _ = extract_demo_features()
    return df


def test_sql_extract_one_row_per_customer(demo):
    assert demo["customer_id"].is_unique
    assert 0.15 < demo["churn"].mean() < 0.35
    assert {"logins_recent", "tickets_90d", "failed_payments"} <= set(demo.columns)


def test_raw_tables_contain_duplicates_that_sql_removes():
    t = generate_demo_tables(500, seed=1)
    assert t["customers"]["customer_id"].duplicated().any()


def test_cleaning_fixes_mess(demo):
    clean, rep = clean_dataframe(demo)
    assert clean["country"].str.strip().eq(clean["country"]).all()
    assert (clean["monthly_price"].dropna() > 0).all()
    assert clean["age"].dropna().between(10, 100).all()
    assert len(rep.steps) >= 3


def test_pipeline_fits_and_predicts(demo):
    clean, _ = clean_dataframe(demo)
    X, y = clean.drop(columns=["churn", "customer_id"]), clean["churn"]
    pipe = make_pipeline("Logistic Regression", X, 0).fit(X, y)
    p = pipe.predict_proba(X.head(20))[:, 1]
    assert p.shape == (20,) and ((p >= 0) & (p <= 1)).all()


@pytest.mark.parametrize("q", ["DROP TABLE data", "SELECT 1; DELETE FROM data", "UPDATE data SET a=1", ""])
def test_sql_guard_blocks_unsafe(q):
    with pytest.raises(ValueError):
        validate_select(q)


def test_user_sql_runs():
    df = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "x"]})
    out = run_user_sql(df, "SELECT b, SUM(a) AS s FROM data GROUP BY b ORDER BY b")
    assert out["s"].tolist() == [4, 2]


def test_custom_dataset_target_detection():
    df = pd.DataFrame({"CustomerID": range(6), "Churn": ["Yes", "No", "No", "Yes", "No", "No"], "x": range(6)})
    assert suggest_target(df) == "Churn"
    out = prepare_custom_frame(df, "Churn", "Yes", "CustomerID")
    assert out["churn"].tolist() == [1, 0, 0, 1, 0, 0] and "customer_id" in out.columns
