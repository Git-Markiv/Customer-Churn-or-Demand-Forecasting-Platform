"""Headless smoke test of the Streamlit app (builds the Quick demo run first if it is not cached)."""
import warnings

from pathlib import Path

from streamlit.testing.v1 import AppTest

warnings.filterwarnings("ignore")


def test_app_renders_all_tabs():
    from src.pipeline import PRESETS, RunConfig, run_or_load
    run_or_load(RunConfig(source="demo", **PRESETS["Quick"]))
    at = AppTest.from_file(str(Path(__file__).resolve().parent.parent / "app.py"), default_timeout=180).run()
    assert not at.exception, at.exception
    assert len(at.tabs) == 8
